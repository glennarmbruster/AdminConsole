﻿#Requires -Version 5.1
# TOOLKIT-VARIANT: Dual
# TOOLKIT-REQUIRES: OwnProcess
#
# ONE WINDOW FOR EVERY KIND OF GROUP, ON EITHER SIDE.
#
# It needs its OWN PROCESS because it can hold an on-premises Exchange session
# and an Exchange Online one in the same window, and both export
# Get-DistributionGroup. Every call here is qualified -- Invoke-OnPremCommand
# or Invoke-EXOCommand -- so which directory answers is decided by this code
# and never by import order.
<#
    Group-Editor.ps1
    One group, every setting, whatever kind of group it is and wherever it
    lives.

    Author   : Glenn Armbruster
    Created  : 2026-09-18

    WHY THIS EXISTS. Three tools looked like group editors and were really a
    router plus two half-editors: Group-Manager.ps1 decided which to open,
    Group-Manager-Editor.ps1 did distribution lists properly on both sides,
    and GroupEditor.ps1 did Microsoft 365 groups because the other one cannot
    -- a Microsoft 365 group answers *-DistributionGroup with "The current
    operation is not supported on GroupMailbox". Add the membership tools and
    the reports and there were eight windows for one object.

    THIS IS THE ROUTER AND BOTH EDITORS IN ONE WINDOW. The routing did not go
    away -- it cannot, the cmdlet families really are different -- it moved
    inside, where it decides which tabs are live rather than which program to
    start.

    NOTHING HERE CREATES OR DELETES A GROUP. An editor that can delete its own
    subject is a different and more dangerous kind of tool; creation lives in
    NewCloudGroup.ps1 and ManageMailObject.ps1, and conversion in
    DLtoSharedMB.ps1.
#>
# TOOLKIT-HELP-RUNS: Reads one group across several tabs, on-premises or in Exchange Online. Each section's Apply changes only that section, and the risky ones ask first.
# TOOLKIT-HELP-BEGIN
# Everything about one group, in tabs. Type an address, press Load.
#
#   Overview   What it is, where it is mastered, hide from the address book,
#              and the 'anything wrong?' verdict.
#   Addresses  Every SMTP address; make one primary, add an alias, remove one.
#   Owners     ManagedBy -- who owns it, add and remove.
#   Members    Who is in it, add and remove; a filter for a dynamic group.
#   Mail Flow  Sender authentication and the allowed-senders list.
#   Send As    Who may send as the group.
#
# IT WORKS OUT WHAT KIND OF GROUP IT IS, and that decides what you can edit:
#
#   Distribution list, mail-enabled security group
#                   -- addresses, owners, members, mail flow, Send As.
#                      On-premises or cloud, decided by where it is mastered.
#   Microsoft 365 group
#                   -- owners and members through a different cmdlet family,
#                      plus the settings Exchange keeps for it. Hide from the
#                      address book and the mail-flow restrictions work on one
#                      of these too, written with Set-UnifiedGroup; they used
#                      to be refused on the belief that they were
#                      distribution-group-only properties, which left them
#                      dead in a cloud-only tenant where this is most of what
#                      you have.
#   Dynamic distribution group
#                   -- membership is a FILTER, not a list. It is shown and
#                      cannot be edited, because there is nothing to edit.
#
# A SYNCED GROUP IS EDITED ON-PREMISES, because a cloud write to a synced
# group appears to succeed and is undone by the next directory sync. The
# window works that out for itself and says which directory it is pointed at.
#
# THE EDITING SWITCH, TOP RIGHT. The same switch the Mailbox and Room Editors
# have. It is normally left where the window put it -- the group's own
# mastering decides the right answer -- but it is there when you need to look
# at the other side, and the banner always says which one is live. If it is
# greyed out, this window has no on-premises Exchange connection (or the
# tenant has none); the reason is on the status line.
#
# HIDE FROM THE ADDRESS BOOK is on the first tab, as it is in the other two
# editors.
#
# DESCRIPTION is on the first tab, and is the one-line box from ADUC's
# General tab -- the field most AD reports read. It is written straight to
# Active Directory, because Set-Group's own Description parameter is Exchange
# Online only. It is HIDDEN, not greyed, whenever there is no directory object
# behind the group: a cloud-only tenant, a cloud-native group, or a synced
# group being looked at in cloud mode. Flip the switch to on-premises to edit
# it on a synced group.
#
# NOTES is on the first tab too, for distribution groups, mail-enabled
# security groups and Microsoft 365 groups. For a Microsoft 365 group it is
# the description Outlook and Teams show. It is written with Set-Group, which
# works the same on-premises and in Exchange Online -- Set-DistributionGroup's
# Description parameter is cloud-only and would have left every on-premises
# group unreadable-and-unwritable, so it is not used.
#
# ONE CAVEAT WORTH KNOWING. Exchange Online also has a separate Description
# property on a distribution group, set with Set-DistributionGroup
# -Description. The references do not say whether that is the same underlying
# attribute as Notes, so a description typed into the admin centre may not
# appear in this box. If the two ever disagree on a group, that is why.
#
# A DYNAMIC DISTRIBUTION GROUP cannot have its notes set here -- the box says
# so and stays disabled.
#
# ADDRESSES is its own tab, like the Mailbox Editor's: make an alias primary,
# add one, remove one. The old primary is kept as an alias and X500 entries are
# never touched. An on-premises group with the e-mail address policy enabled
# is shown read-only until the policy row under the list is unticked.
#
# ON-PREMISES GROUPS IN EITHER DIRECTORY. The window asks both directories
# before it decides, sets forest scope for the read, and pins the domain
# controller to the group's own domain -- which is what makes groups outside
# the primary domain list their members instead of coming back empty.
#
# EACH BLOCK HAS ITS OWN APPLY. There is no global Save.
#
# WHAT IT WILL NOT DO: create a group, delete a group, or convert one type
# into another. Those are separate tools on purpose.
# TOOLKIT-HELP-END

param(
    [string]$SmtpAddress,
    [string]$Environment,
    # Forced on-premises, the way Group-Manager used to launch its editor.
    [switch]$OnPrem
)

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

. (Join-Path $PSScriptRoot 'Common.ps1')

if (-not (Test-ConsoleLaunch)) { return }

#region State and routing -------------------------------------------------------
$script:Grp     = $null    # the resolved group
$script:Mode    = 'Cloud'  # what the Editing switch says
$script:OnPremWhy = ''     # why the switch is unavailable, if it is
$script:Loaded  = @{}
$script:Busy    = $false
$script:Closing = $false   # set by FormClosing; see the tab handler at the foot of the file
$script:TabReadFailed = $false

# THE DOMAIN CONTROLLER, PINNED ONCE AND USED FOR EVERY ON-PREMISES CALL.
#
# -DomainController wants a REAL CONTROLLER, never a domain name.
# Get-TenantDirectoryServer deliberately returns the DOMAIN when a directory
# has several controllers, and Exchange rejects that with "Active Directory
# error 0x52 ... suitability of server", which reads as a broken server and is
# not one. A wrong pin fails as "out of the current user's write scope", which
# reads as a permissions problem and is not one either.
#
# NO PIN IS A VALID ANSWER. An empty splat lets Exchange choose, which works.
# What must not happen is the READ landing on one controller and the WRITE on
# another, so whatever is chosen is used for everything.
$script:DCParam  = @{}
$script:DCDetail = ''   # what the banner says about scope and pinning

function Invoke-GrpCmd {
    <#
        THE ONLY PLACE THAT KNOWS THE DIFFERENCE between the two directories.

        Every read and every write in this file goes through here. Written the
        other way -- an if/else at each call site -- there are forty chances to
        get it wrong and one of them will be a write.
    #>
    param(
        [Parameter(Mandatory)][string]$Name,
        [hashtable]$Parameters = @{}
    )
    # The caller's hashtable is COPIED before the controller is added to it.
    # Adding in place mutates a table the caller may reuse, and the second call
    # then carries a parameter the caller never asked for.
    $p = @{} + $Parameters
    if ($script:Grp -and $script:Grp.OnPrem) {
        foreach ($k in $script:DCParam.Keys) { $p[$k] = $script:DCParam[$k] }
        return Invoke-OnPremCommand -Name $Name -Parameters $p
    }
    return Invoke-EXOCommand -Name $Name -Parameters $p
}

function Invoke-GrpSendAsWrite {
    <#
        The on-premises Send-As write (Add-/Remove-ADPermission), done the way
        the older Send-As tools did it -- the ones that worked.

        NO CONTROLLER PIN ON THE FIRST ATTEMPT. AD-DL_SendToAs and
        DL-Manager-SendToAs passed no -DomainController for these writes and
        let Exchange choose; this editor pinned every call to a controller in
        the group's own domain, and that pinned write was refused with
        INSUFF_ACCESS_RIGHTS (2026-09-25) where the unpinned one had worked for
        months. Microsoft KB 3096158: the write is made as the Exchange
        server's computer account, so which controller evaluates that
        account's token matters -- the operator's rights never enter into it.

        ONLY IF THE UNPINNED WRITE FAILS is the pinned controller tried, so a
        directory where the pin is genuinely needed loses nothing.

        Returns the controller that took the write ('' = Exchange's choice),
        so the caller can warn that a re-read pinned elsewhere may lag
        replication. Throws the LAST error if both attempts fail.
    #>
    param(
        [Parameter(Mandatory)][ValidateSet('Add-ADPermission', 'Remove-ADPermission')][string]$Name,
        [Parameter(Mandatory)][hashtable]$Parameters
    )
    $p = @{} + $Parameters
    [void]$p.Remove('DomainController')
    try {
        Invoke-OnPremCommand -Name $Name -Parameters $p | Out-Null
        return ''
    } catch {
        $first = $_
        $pin = "$($script:DCParam['DomainController'])".Trim()
        if (-not $pin) { throw $first }
        $p2 = @{} + $p
        $p2['DomainController'] = $pin
        Invoke-OnPremCommand -Name $Name -Parameters $p2 | Out-Null
        return $pin
    }
}

function Set-GrpDomainController {
    <#
        Point the on-premises session at the right place for THIS group.

        TWO THINGS THAT BOTH HAD TO CHANGE, and between them they are why a
        group in a child domain loaded its identity and then showed an empty
        member list:

        ONE -- THE SESSION SCOPE. Set-ADSessionScope puts the session
        forest-wide. Without it an Exchange session sees only its own domain,
        and a group whose members live elsewhere returns NO MEMBERS rather
        than an error. An empty grid is indistinguishable from a group that
        genuinely has nobody in it, which is why this went unnoticed.

        TWO -- WHICH CONTROLLER. The old version pinned the FIRST directory
        that answered, which for a child-domain group is usually the parent's
        controller. A controller that cannot resolve the members drops them
        quietly. The directory is now taken from the group's own distinguished
        name, and if that cannot be matched NOTHING is pinned -- forest-wide
        with no pin is correct and safe, and a wrong pin is not.
    #>
    $script:DCParam = @{}
    $script:DCDetail = 'no controller pinned'

    # FOREST-WIDE FIRST, ALWAYS. This is the half that fixes the empty list.
    try {
        $scope = Set-ADSessionScope
        if ($scope) { $script:DCDetail = "$($scope.Detail)" }
    } catch {
        $script:DCDetail = "could not set the forest scope: $($_.Exception.Message)"
        return
    }

    $dir = $null
    try { $dir = Get-DirectoryFromDn -Dn "$(if ($script:Grp) { $script:Grp.Dn })" } catch { }
    if (-not $dir) {
        $script:DCDetail += ' The group''s domain does not match any configured directory, so no controller is pinned -- forest-wide covers it.'
        return
    }
    $srv = ''
    try { $srv = Resolve-DirectoryDomainController -DirectoryId "$($dir.Id)" } catch { }
    if ("$srv".Trim()) {
        $script:DCParam = @{ DomainController = "$srv" }
        $script:DCDetail = "pinned to $srv for $($dir.Label)"
    } else {
        $script:DCDetail += " No controller resolved for $($dir.Label); forest-wide."
    }
}

function Resolve-GroupTarget {
    <#
        What kind of group is this, and which directory masters it.

        GET-RECIPIENT IS ASKED FIRST, and that ordering is load-bearing. A
        Microsoft 365 group answers Get-DistributionGroup with "The current
        operation is not supported on GroupMailbox", so a tool that asks that
        first reports three real groups as unroutable.

        IsDirSynced IS NEVER CACHED between loads. It is correct until the
        weekend the group converts, and then it is confidently wrong.
    #>
    param([Parameter(Mandatory)][string]$Identity, [bool]$ForceOnPrem = $false)

    $r = [PSCustomObject]@{
        Ok = $false; Smtp = ''; Display = ''; Name = ''; Alias = ''
        Kind = ''            # Distribution | Security | Unified | Dynamic
        Type = ''            # the raw RecipientTypeDetails
        OnPrem = $false; IsSynced = $false
        EmsHere = $false     # was an on-premises Exchange session available
        FoundIn = ''         # 'Cloud' or 'OnPrem' -- which directory answered
        Raw = $null; Dn = ''; Reason = ''
    }

    # THE BARE LOCAL PART IS TRIED TOO. Get-TargetSmtp completes a bare word
    # with the tenant's primary domain, and a group whose only address is
    # @tenant.onmicrosoft.com does not have one -- which is most groups nobody
    # gave a vanity address to.
    $tries = @("$Identity")
    if ("$Identity" -match '^([^@]+)@') { $tries += $Matches[1] }

    # BOTH DIRECTORIES ARE ASKED, AND THE CLOUD IS NOT ASKED FIRST WHEN THE
    # CALLER ALREADY SAID ON-PREMISES.
    #
    # THE BUG THIS FIXES, because it made the window useless for a whole class
    # of group: the resolve was Exchange Online only. A group that lives in a
    # child domain, or that has not synchronised, or that is simply not
    # mail-enabled in the cloud, was reported as "not found in Exchange
    # Online" -- and every on-premises group in a directory the cloud does not
    # carry showed nothing at all.
    #
    # THE FOREST SCOPE IS SET BEFORE THE ON-PREMISES READ. A child-domain
    # object is invisible to an Exchange session scoped to its own domain, and
    # invisible looks exactly like absent. Set-ADSessionScope puts the session
    # forest-wide first and only then tries to pin a controller.
    $rec = $null
    $onPremFirst = $ForceOnPrem
    $order = $(if ($onPremFirst) { @('OnPrem', 'Cloud') } else { @('Cloud', 'OnPrem') })
    $emsHere = $false
    try { $emsHere = [bool](Test-EmsAvailable).Available } catch { }

    foreach ($where in $order) {
        if ($rec) { break }
        if ($where -eq 'OnPrem') {
            if (-not $emsHere) { continue }
            try { $null = Set-ADSessionScope } catch { }
        }
        foreach ($t in $tries) {
            try {
                $hit = @(& $(if ($where -eq 'OnPrem') { 'Invoke-OnPremCommand' } else { 'Invoke-EXOCommand' }) `
                            -Name 'Get-Recipient' -Parameters @{
                                Identity = $t; ResultSize = 1; ErrorAction = 'Stop'; WarningAction = 'SilentlyContinue' })
                if (@($hit).Count -ge 1) { $rec = $hit[0]; $r.FoundIn = $where; break }
            } catch { }
        }
    }

    if (-not $rec) {
        $r.Reason = $(if ($emsHere) {
            'was not found in Exchange Online or on-premises. Check the spelling, and that the group is in a directory this console is configured for.'
        } else {
            'was not found in Exchange Online, and on-premises Exchange is not connected in this window so the on-premises directory was not searched.'
        })
        return $r
    }

    $r.Smtp    = "$($rec.PrimarySmtpAddress)"
    $r.Display = "$($rec.DisplayName)"
    $r.Name    = "$($rec.Name)"
    $r.Alias   = "$($rec.Alias)"
    $r.Type    = "$($rec.RecipientTypeDetails)"
    $r.Dn      = "$($rec.DistinguishedName)"

    switch -Regex ($r.Type) {
        'GroupMailbox'                      { $r.Kind = 'Unified' }
        'DynamicDistributionGroup'          { $r.Kind = 'Dynamic' }
        'MailUniversalSecurityGroup'        { $r.Kind = 'Security' }
        'MailUniversalDistributionGroup'    { $r.Kind = 'Distribution' }
        'RoomList'                          { $r.Kind = 'Distribution' }
        default                             { $r.Kind = '' }
    }
    if (-not $r.Kind) {
        $r.Reason = "is a $($r.Type), which is not a group this window edits."
        return $r
    }

    # WHICH SIDE IS DECIDED FIRST, FROM THE CHEAP CLOUD LOOKUP, because the
    # detail has to be read from the directory that is going to be WRITTEN.
    #
    # Reading it from Exchange Online for an on-premises group looks harmless
    # and is not: an on-premises write is not visible in the cloud until the
    # next sync, so every re-read after an Apply repaints the tab from the
    # pre-change copy. The checkboxes snap back, the owner grid shows the old
    # list, and the window contradicts what it has just done.
    # A GROUP THE CLOUD HAS NEVER HEARD OF IS AN ON-PREMISES GROUP, whatever
    # IsDirSynced says -- that property is meaningless on an object the cloud
    # did not return.
    # ON-PREMISES ONLY IF THERE IS AN ON-PREMISES SESSION TO USE. Without one,
    # claiming the on-prem side sends the detail read to a module that is not
    # loaded and the group appears unreadable -- when the cloud copy was
    # sitting right there. The banner then says the cloud copy is being shown
    # and why.
    $r.IsSynced = [bool]$rec.IsDirSynced
    $r.OnPrem   = ($emsHere -and ($ForceOnPrem -or $r.IsSynced -or ($r.FoundIn -eq 'OnPrem')))
    $r.EmsHere  = $emsHere
    # A Microsoft 365 group has no on-premises half to write to.
    if ($r.Kind -eq 'Unified') { $r.OnPrem = $false }

    # $script:Grp is what Invoke-GrpCmd routes on, so it has to be set before
    # the detail read goes through it.
    $script:Grp = $r

    # AND THE SCOPE HAS TO BE RIGHT BEFORE THAT READ, TOO.
    #
    # The detail read below is the FIRST on-premises call for this group, and
    # it used to run with whatever controller the PREVIOUS group had pinned --
    # or none, and without forest scope, which for a child-domain object means
    # reading nothing and reporting that as the group's contents. The pin is
    # cleared first so a stale one cannot leak across a load.
    if ($r.OnPrem) {
        $script:DCParam = @{}
        try { $null = Set-ADSessionScope } catch { }
    }

    try {
        switch ($r.Kind) {
            'Unified' {
                # ALWAYS CLOUD. There is no on-premises Get-UnifiedGroup.
                $r.Raw = Invoke-EXOCommand -Name 'Get-UnifiedGroup' -Parameters @{ Identity = $r.Smtp; ErrorAction = 'Stop' }
            }
            'Dynamic' {
                $r.Raw = Invoke-GrpCmd -Name 'Get-DynamicDistributionGroup' -Parameters @{ Identity = $r.Smtp; ErrorAction = 'Stop' }
            }
            default {
                $r.Raw = Invoke-GrpCmd -Name 'Get-DistributionGroup' -Parameters @{ Identity = $r.Smtp; ErrorAction = 'Stop' }
            }
        }
    } catch {
        $r.Reason = "was found as a $($r.Type) but its detail could not be read$(if ($r.OnPrem) { ' on-premises' }): $($_.Exception.Message)"
        return $r
    }

    $r.Ok = $true
    return $r
}
#endregion

#region Form shell --------------------------------------------------------------
$form = New-Object System.Windows.Forms.Form
$form.Text          = 'Group Editor'
$form.ClientSize    = New-Object System.Drawing.Size(1120, 760)
$form.StartPosition = 'Manual'
$form.Font          = New-Object System.Drawing.Font('Microsoft Sans Serif', 9)

$y = 12
$lblWho          = New-Object System.Windows.Forms.Label
$lblWho.Text     = 'Group:'
$lblWho.Location = New-Object System.Drawing.Point(12, ($y + 3))
$lblWho.Size     = New-Object System.Drawing.Size(48, 18)
$form.Controls.Add($lblWho)

$txtGrp          = New-Object System.Windows.Forms.TextBox
$txtGrp.Location = New-Object System.Drawing.Point(62, $y)
$txtGrp.Size     = New-Object System.Drawing.Size(340, 24)
$txtGrp.Font     = New-Object System.Drawing.Font('Consolas', 9)
$txtGrp.Text     = "$(Get-TargetSmtp -Text $SmtpAddress)"
$form.Controls.Add($txtGrp)

$btnLoad          = New-Object System.Windows.Forms.Button
$btnLoad.Text     = 'Load'
$btnLoad.Location = New-Object System.Drawing.Point(412, ($y - 2))
$btnLoad.Size     = New-Object System.Drawing.Size(90, 28)
$form.Controls.Add($btnLoad)

# THE EDITING SWITCH, from Common.ps1 -- the identical control the Mailbox and
# Room editors get, in the same place and with the same wording.
$cmbMode = New-EditorModeSwitch -Form $form -X 718 -Y $y -LabelX 660

$btnClose          = New-Object System.Windows.Forms.Button
$btnClose.Text     = 'Close'
$btnClose.Location = New-Object System.Drawing.Point(952, ($y - 2))
$btnClose.Size     = New-Object System.Drawing.Size(90, 28)
$btnClose.Add_Click({ $form.Close() })
$form.Controls.Add($btnClose)
$y += 34

$lblIdent           = New-Object System.Windows.Forms.Label
$lblIdent.Tag       = 'NoTheme'
$lblIdent.Location  = New-Object System.Drawing.Point(12, $y)
$lblIdent.Size      = New-Object System.Drawing.Size(1096, 18)
$lblIdent.Font      = New-Object System.Drawing.Font('Microsoft Sans Serif', 9, [System.Drawing.FontStyle]::Bold)
$lblIdent.ForeColor = (Get-ToolStatusColour -Kind Muted)
$lblIdent.Text      = 'No group loaded.'
$form.Controls.Add($lblIdent)
$y += 20

$lblSync           = New-Object System.Windows.Forms.Label
$lblSync.Tag       = 'NoTheme'
$lblSync.Location  = New-Object System.Drawing.Point(12, $y)
$lblSync.Size      = New-Object System.Drawing.Size(1096, 18)
$lblSync.ForeColor = (Get-ToolStatusColour -Kind Muted)
$lblSync.Text      = ''
$form.Controls.Add($lblSync)
$y += 22

$tabs          = New-Object System.Windows.Forms.TabControl
$tabs.Location = New-Object System.Drawing.Point(12, $y)
$tabs.Size     = New-Object System.Drawing.Size(1096, 640)
$form.Controls.Add($tabs)

$lblStatus           = New-Object System.Windows.Forms.Label
$lblStatus.Location  = New-Object System.Drawing.Point(12, ($y + 646))
$lblStatus.Size      = New-Object System.Drawing.Size(1096, 18)
$lblStatus.ForeColor = (Get-ToolStatusColour -Kind Muted)
$lblStatus.Text      = 'Enter a group address and press Load.'
$form.Controls.Add($lblStatus)

$form.ClientSize = New-Object System.Drawing.Size(1120, ($lblStatus.Bottom + 12))


# ---- register with the shared editor runtime ----------------------------------
# UsesOnPremObject is $false: a group is not edited through a separate
# on-premises object the way a mailbox is. It is RE-RESOLVED for the other
# directory, and that can fail -- so the mode hook below does the resolve and
# vetoes the switch when the group has no half on the side that was asked for.
Initialize-TabbedEditor -Name 'Group' -Noun 'group' -ObjectName 'Grp' `
    -Form $form -Tabs $tabs -StatusLabel $lblStatus -IdentityLabel $lblIdent -SyncLabel $lblSync -ModeCombo $cmbMode `
    -UsesOnPremObject $false `
    -TabLoaders @{
        Overview  = { Update-OverviewTab }
        Addresses = { Update-AddressesTab }
        Owners   = { Update-OwnersTab }
        Members  = { Update-MembersTab }
        MailFlow = { Update-MailFlowTab }
        Access   = { Update-SendAsTab }
    } `
    -OnModeChange {
        param($Mode)
        $prev = $script:Grp
        if (-not $prev -or -not $prev.Ok) { return $true }
        $g = Resolve-GroupTarget -Identity $prev.Smtp -ForceOnPrem:($Mode -eq 'OnPrem')
        if (-not $g.Ok) {
            # RESOLVE-GROUPTARGET WRITES $script:Grp ON THE WAY THROUGH, so a
            # failed re-resolve has already replaced the loaded group with the
            # failure. Put the good one back before saying no.
            $script:Grp = $prev
            Set-EditorStatus -Text "Cannot edit this group $(if ($Mode -eq 'OnPrem') { 'on-premises' } else { 'in the cloud' }): $($g.Reason)" -Warn
            return $false
        }
        $script:Grp = $g
        if ($g.OnPrem) { Set-GrpDomainController } else { $script:DCParam = @{} }
        # The group's own mastering decides the mode we actually end up in.
        $script:Mode = $(if ($g.OnPrem) { 'OnPrem' } else { 'Cloud' })
        return $true
    } `
    -Identity {
        param($g)
        $kindText = switch ($g.Kind) {
            'Unified'      { 'Microsoft 365 group' }
            'Dynamic'      { 'dynamic distribution group' }
            'Security'     { 'mail-enabled security group' }
            'Distribution' { 'distribution list' }
            default        { $g.Type }
        }
        if ($g.OnPrem) {
            $sync = "EDITED ON-PREMISES -- $(if ($script:DCDetail) { $script:DCDetail } else { 'forest-wide' }). This group is mastered in Active Directory; a cloud write would be accepted and undone by the next directory sync."; $sc = 'Warn'
        } elseif ($g.IsSynced -and -not $g.EmsHere) {
            $sync = 'SYNCED FROM ACTIVE DIRECTORY, and this window has no on-premises Exchange session -- so you are seeing the CLOUD copy. Writes here will be undone by the next directory sync. Open this from a console with on-premises Exchange connected.'; $sc = 'Bad'
        } elseif ($g.IsSynced) {
            $sync = 'SYNCED FROM ACTIVE DIRECTORY but edited in the cloud -- a Microsoft 365 group has no on-premises half.'; $sc = 'Warn'
        } else {
            $sync = 'Cloud group -- edited in Exchange Online.'; $sc = 'Muted'
        }
        @{ Text = "$($g.Display)   <$($g.Smtp)>   $kindText"; Colour = 'Good'; Sync = $sync; SyncColour = $sc }
    }

$tabOverview = New-EditorTab -Key 'Overview' -Text 'Overview'
$tabAddresses = New-EditorTab -Key 'Addresses' -Text 'Addresses'
$tabOwners   = New-EditorTab -Key 'Owners'   -Text 'Owners'
$tabMembers  = New-EditorTab -Key 'Members'  -Text 'Members'
$tabMailFlow = New-EditorTab -Key 'MailFlow' -Text 'Mail Flow'
$tabAccess   = New-EditorTab -Key 'Access'   -Text 'Send As'
#endregion

#region Shell helpers -----------------------------------------------------------




function Test-GrpKind {
    <#
        Refuse an action this kind of group cannot do, and say why.

        A DYNAMIC GROUP HAS NO MEMBER LIST AT ALL -- its membership is a
        filter evaluated at send time. Add-DistributionGroupMember against one
        fails with a message about the identity, which reads as the group not
        existing.
    #>
    param([string[]]$Allow, [string]$What = 'This')
    if (-not $script:Grp) { return $false }
    if ($Allow -contains $script:Grp.Kind) { return $true }
    $why = switch ($script:Grp.Kind) {
        'Dynamic' { "$What does not apply to a dynamic distribution group -- its membership is a filter, not a list. The filter is on the Members tab." }
        # NARROWER THAN IT WAS. Hide-from-GAL and the mail-flow settings are
        # no longer refused for a Microsoft 365 group, so this message is now
        # only reached by the things that really are unavailable -- and it
        # says which cmdlet family owns them rather than just 'no'.
        'Unified' { "$What is not available for a Microsoft 365 group here -- it is not one of the settings Set-UnifiedGroup carries." }
        default   { "$What does not apply to a $($script:Grp.Type)." }
    }
    Set-EditorStatus -Text $why -Bad
    $null = Show-ToolDialog($why, 'Not available for this kind of group', 'OK', 'Information')
    return $false
}


function Resolve-GrpRecipient {
    <#
        One name, turned into the things the write actually needs.

        PrimarySmtpAddress IS THE KEY, NEVER Identity. Identity for a group
        comes back as its Active Directory CN, and feeding that back to a
        cmdlet is a fresh forest-wide NAME lookup rather than a bind -- which
        can land on a different object entirely.

        Sam is carried because the on-premises Send-As write needs it: the
        *-ADPermission cmdlets take a trustee that AD recognises, and an SMTP
        address is not one.
    #>
    param([string]$Entry)
    $r = [PSCustomObject]@{ Ok = $false; Raw = "$Entry"; Name = "$Entry"; Address = ''; Sam = ''; Dn = ''; Type = ''; Reason = '' }
    if (-not "$Entry".Trim()) { $r.Reason = 'empty'; return $r }
    # RESOLVED IN THE DIRECTORY THAT WILL BE WRITTEN, which is two separate
    # problems solved at once. Exchange Online's Get-Recipient does not
    # populate SamAccountName, and the on-premises Send As write needs one; and
    # a trustee that exists only on-premises is simply not in Exchange Online
    # to be found, so the handler would abort with 'nothing was changed' for a
    # write that would have worked.
    try {
        $hit = @(Invoke-GrpCmd -Name 'Get-Recipient' -Parameters @{
                    Identity = $Entry; ErrorAction = 'Stop'; WarningAction = 'SilentlyContinue' })
        if (@($hit).Count -gt 1) { $r.Reason = 'more than one recipient matches'; return $r }
        if (@($hit).Count -eq 1) {
            $r.Ok      = $true
            $r.Name    = "$($hit[0].DisplayName)"
            $r.Address = "$($hit[0].PrimarySmtpAddress)"
            $r.Sam     = "$($hit[0].SamAccountName)"
            $r.Dn      = "$($hit[0].DistinguishedName)"
            # Where this person's mailbox lives, as the directory that answered
            # sees it -- Send As on a synced group is written where the SENDER
            # is (see Test-GrpNeedsOnPremSendAs).
            $r.Type    = "$($hit[0].RecipientTypeDetails)"
            return $r
        }
    } catch { $r.Reason = $_.Exception.Message; return $r }
    $r.Reason = 'not found'
    return $r
}
#endregion

#region Overview tab ------------------------------------------------------------
$ovY = 8
[void](New-TabLabel $tabOverview 'IDENTITY' 8 $ovY -Bold)
$ovY += 22
[void](New-TabLabel $tabOverview 'Display name:' 8 $ovY)
$ovName = New-TabValue $tabOverview 170 $ovY 360
[void](New-TabLabel $tabOverview 'Kind:' 560 $ovY 135)
$ovKind = New-TabValue $tabOverview 700 $ovY 320
$ovY += 24
[void](New-TabLabel $tabOverview 'Address:' 8 $ovY)
$ovSmtp = New-TabValue $tabOverview 170 $ovY 360
[void](New-TabLabel $tabOverview 'Alias:' 560 $ovY 135)
$ovAlias = New-TabValue $tabOverview 700 $ovY 320
$ovY += 24
[void](New-TabLabel $tabOverview 'Name:' 8 $ovY)
$ovRawName = New-TabValue $tabOverview 170 $ovY 360
[void](New-TabLabel $tabOverview 'Mastered in:' 560 $ovY 135)
$ovSource = New-TabValue $tabOverview 700 $ovY 320
$ovY += 28

# HIDE-FROM-GAL ON THE FIRST TAB, in all three editors. 'Can people find this'
# belongs beside 'what is this', and the Room Editor had it right first.
[void](New-TabLabel $tabOverview 'Hide from the address book:' 8 ($ovY + 3) 180)
$cmbOvHide               = New-Object System.Windows.Forms.ComboBox
$cmbOvHide.DropDownStyle = 'DropDownList'
$cmbOvHide.Location      = New-Object System.Drawing.Point(196, $ovY)
$cmbOvHide.Size          = New-Object System.Drawing.Size(110, 24)
[void]$cmbOvHide.Items.Add('True'); [void]$cmbOvHide.Items.Add('False')
$tabOverview.Controls.Add($cmbOvHide)
$btnOvHide = New-TabButton $tabOverview 'Apply' 320 ($ovY - 2) 100
$ovHideNote = New-TabLabel $tabOverview '' 430 ($ovY + 3) 600 -Muted
$ovY += 32

# ADDRESSES HAVE THEIR OWN TAB NOW, as they do in the Mailbox Editor. One line
# here says how many and which is primary; the tab is where they are edited.
[void](New-TabLabel $tabOverview 'Addresses:' 8 $ovY 150)
$ovAddrLine = New-TabValue $tabOverview 170 $ovY 850
$ovY += 30

# NOTES -- AND WHY IT IS Set-Group RATHER THAN Set-DistributionGroup.
#
# There are two different parameter names for what is really one idea, and
# picking the wrong one breaks the hybrid case outright:
#
#   Set-DistributionGroup -Description   EXCHANGE ONLINE ONLY. Its Applicable
#                                        line names Exchange Online and the
#                                        security add-on, not Exchange Server
#                                        2016/2019/SE, and the body says
#                                        outright that it is cloud-only. A
#                                        group mastered on-premises -- which
#                                        is most of them here -- could not be
#                                        edited through it at all.
#   Set-Group -Notes                     BOTH. Applicable to Exchange Server
#                                        2010 through SE AND Exchange Online.
#                                        One parameter, one code path, works
#                                        whichever way the switch is set.
#   Set-UnifiedGroup -Notes              Microsoft 365 groups, cloud only,
#                                        and the reference says plainly that
#                                        Notes 'specifies the description of
#                                        the Microsoft 365 Group'.
#
# So Set-Group carries distribution and mail-enabled security groups, and
# Set-UnifiedGroup carries Microsoft 365 groups. Set-DistributionGroup is not
# used for this at all.
#
# A DYNAMIC GROUP IS REFUSED, not silently ignored. Set-Group's own reference
# says it cannot modify dynamic distribution groups and points at
# Set-DynamicDistributionGroup, which is not wired up here -- so the box says
# so rather than offering a write that cannot land.
# DESCRIPTION -- ACTIVE DIRECTORY ONLY, AND HIDDEN RATHER THAN GREYED.
#
# This is the one-line box at the top of ADUC's General tab, the field most AD
# reports and scripts actually read. It is NOT the Notes box below it: they
# are separate attributes holding separate text, and merging them into one
# control would silently overwrite whichever one the operator did not mean.
#
# THERE IS NO EXCHANGE PATH TO IT ON-PREMISES. Set-Group and
# Set-DistributionGroup both declare -Description and on both it is Exchange
# Online only, so this goes at the directory attribute directly -- see the
# Directory description region in Common.ps1.
#
# HIDDEN, NOT GREYED, when there is nothing to write to. A cloud-only tenant
# has no Active Directory at all, and a greyed box invites the question 'why
# can't I edit this' about a field that does not exist. The test is whether
# the group's own distinguished name belongs to a CONFIGURED directory --
# which also, correctly, hides it for a cloud-native group and for a synced
# group being viewed in cloud mode, where the DN on hand is Exchange Online's
# and not one Get-ADObject could ever resolve.
$lblOvDescCap = New-TabLabel $tabOverview 'Description:' 8 ($ovY + 3) 150
$txtOvDesc          = New-Object System.Windows.Forms.TextBox
$txtOvDesc.Location = New-Object System.Drawing.Point(170, $ovY)
$txtOvDesc.Size     = New-Object System.Drawing.Size(700, 24)
$tabOverview.Controls.Add($txtOvDesc)
$btnOvDesc = New-TabButton $tabOverview 'Apply' 880 ($ovY - 2) 100
$ovY += 28
$ovDescNote = New-TabLabel $tabOverview '' 8 $ovY 1040 -Muted
$ovY += 22

[void](New-TabLabel $tabOverview 'Notes:' 8 ($ovY + 3) 150)
$txtOvNotes            = New-Object System.Windows.Forms.TextBox
$txtOvNotes.Location   = New-Object System.Drawing.Point(170, $ovY)
$txtOvNotes.Size       = New-Object System.Drawing.Size(700, 50)
$txtOvNotes.Multiline  = $true
$txtOvNotes.ScrollBars = 'Vertical'
$tabOverview.Controls.Add($txtOvNotes)
$btnOvNotes = New-TabButton $tabOverview 'Apply' 880 $ovY 100
$ovY += 56
$ovNotesNote = New-TabLabel $tabOverview '' 8 $ovY 1040 -Muted
$ovY += 22

# THE SAME BOX EVERY EDITOR HAS.
# TRIMMED FROM 300 to make room for the notes field above it. The address grid
# that used to sit here moved to its own tab, and this is what that room went
# to in the end.
$ovVerdict = Add-EditorVerdictBox -Tab $tabOverview -Y $ovY -Height 200
$ovY += 232

function Get-GrpNotes {
    <#
        The group's notes, from whichever object actually carries them.

        WHY THIS IS NOT SIMPLY $Raw.Notes. A Microsoft 365 group is loaded
        with Get-UnifiedGroup, which does return Notes. A distribution or
        mail-enabled security group is loaded with Get-DistributionGroup,
        whose published reference lists no Notes property at all -- the notes
        live on the object Get-Group returns. So when the loaded object has no
        Notes to give, one extra read asks the cmdlet that owns them.

        THE EXTRA READ IS SKIPPED whenever the loaded object already has the
        property, and a failure degrades to empty rather than throwing. An
        unreadable notes field is not worth failing a tab load over.
    #>
    $g = $script:Grp
    if (-not $g) { return '' }
    if ($g.Raw -and $g.Raw.PSObject.Properties['Notes']) { return "$($g.Raw.Notes)" }
    if ($g.Kind -eq 'Unified') { return '' }
    # A DYNAMIC GROUP IS NOT ASKED OF Get-Group. Set-Group's reference says it
    # cannot modify one, so reading its notes from there and then failing to
    # write them back would be the worst of both. If the loaded object did not
    # carry Notes above, there is nothing more to try.
    if ($g.Kind -eq 'Dynamic') { return '' }
    try {
        $o = Invoke-GrpCmd -Name 'Get-Group' -Parameters @{ Identity = $g.Smtp; ErrorAction = 'Stop' }
        return "$($o.Notes)"
    } catch { return '' }
}

function Update-OverviewTab {
    $g  = $script:Grp
    $gr = $g.Raw
    $ovName.Text    = "$($gr.DisplayName)"
    $ovKind.Text    = "$($g.Type)"
    $ovSmtp.Text    = "$($g.Smtp)"
    $ovAlias.Text   = "$($gr.Alias)"
    $ovRawName.Text = "$($gr.Name)"
    $ovSource.Text  = $(if ($g.OnPrem) { 'Active Directory (on-premises)' } elseif ($g.IsSynced) { 'Active Directory, edited in the cloud' } else { 'Exchange Online' })

    # A MICROSOFT 365 GROUP HIDES DIFFERENTLY. HiddenFromAddressListsEnabled
    # is a distribution-group property; the Unified cmdlets have their own,
    # and Set-DistributionGroup refuses the object outright -- so the control
    # says so rather than offering a write that cannot land.
    $cmbOvHide.SelectedItem = $(if ($gr.HiddenFromAddressListsEnabled) { 'True' } else { 'False' })
    # HIDE-FROM-GAL IS AVAILABLE ON EVERY KIND, INCLUDING MICROSOFT 365.
    # This used to read '$g.Kind -ne \'Unified\'' on the belief that it was a
    # distribution-group-only property. Set-UnifiedGroup declares
    # -HiddenFromAddressListsEnabled, Applicable to Exchange Online -- so the
    # control was dead for the one group type a cloud-only tenant is mostly
    # made of. It is routed by kind now rather than refused.
    $canHide = $true
    $cmbOvHide.Enabled = $canHide; $btnOvHide.Enabled = $canHide
    $ovHideNote.Text = $(if ($g.Kind -eq 'Unified') {
        'Written with Set-UnifiedGroup. Removes the group from the address book; mail sent straight to its address still delivers.'
    } elseif ($g.OnPrem) {
        "Written on-premises. $($script:OnPremSyncNotice)"
    } else {
        'Removes the group from the address book. Mail sent straight to its address still delivers.'
    })
    $ovHideNote.ForeColor = $(if ($g.OnPrem) { (Get-ToolStatusColour -Kind Warn) }
                              else { (Get-ToolStatusColour -Kind Muted) })

    # DESCRIPTION. Shown only when the group's DN belongs to a configured
    # directory -- see the comment on the control.
    $descDir = $null
    try { $descDir = Get-DirectoryFromDn -Dn "$($g.Dn)" } catch { $descDir = $null }
    $showDesc = [bool]$descDir
    foreach ($c in @($lblOvDescCap, $txtOvDesc, $btnOvDesc, $ovDescNote)) { $c.Visible = $showDesc }
    if ($showDesc) {
        $d = Get-AdDescription -Dn "$($g.Dn)"
        $txtOvDesc.Text = $d.Text
        # MORE THAN ONE VALUE IS READ-ONLY. description is multi-valued in the
        # schema, and writing one value back would discard the others.
        $multi = ($d.Count -gt 1)
        $txtOvDesc.ReadOnly = (-not $d.Ok) -or $multi
        $btnOvDesc.Enabled  = $d.Ok -and (-not $multi)
        $ovDescNote.Text = $(if (-not $d.Ok) {
            "The directory description could not be read: $($d.Reason)"
        } elseif ($multi) {
            "This object carries $($d.Count) description values, so it is shown read-only -- writing one back would discard the rest. Use Attributes to work on them."
        } else {
            "Active Directory in $($descDir.Label). The one-line Description on ADUC's General tab -- not the same field as Notes. $($script:OnPremSyncNotice)"
        })
        $ovDescNote.ForeColor = $(if (-not $d.Ok) { (Get-ToolStatusColour -Kind Bad) }
                                  elseif ($multi) { (Get-ToolStatusColour -Kind Warn) }
                                  else { (Get-ToolStatusColour -Kind Muted) })
    }

    # NOTES. Distribution, mail-enabled security and Microsoft 365 groups all
    # have them; a dynamic group is the one that cannot be written here.
    # DYNAMIC GROUPS HAVE NOTES TOO. This used to exclude them on the grounds
    # that their notes 'need Set-DynamicDistributionGroup, which this window
    # does not use' -- which was true only because nothing had taught it to.
    # Set-DynamicDistributionGroup declares -Notes; Get-GrpNotesCmdlet routes
    # to it.
    $canNotes = (@('Distribution', 'Security', 'Unified', 'Dynamic') -contains $g.Kind)
    $txtOvNotes.Text    = Get-GrpNotes
    $txtOvNotes.Enabled = $canNotes
    $btnOvNotes.Enabled = $canNotes
    $ovNotesNote.Text = $(if (-not $canNotes) {
        "Notes are not available for a $($g.Type)."
    } elseif ($g.Kind -eq 'Dynamic') {
        'Written with Set-DynamicDistributionGroup. The membership filter is on the Members tab and is not edited here.'
    } elseif ($g.Kind -eq 'Unified') {
        'The description people see on a Microsoft 365 group in Outlook and Teams. Written with Set-UnifiedGroup.'
    } elseif ($g.OnPrem) {
        "Written on-premises with Set-Group. $($script:OnPremSyncNotice)"
    } elseif ($g.IsSynced -and $g.Kind -ne 'Unified') {
        # LEFT EDITABLE, BUT SAID OUT LOUD. This group is mastered in Active
        # Directory, so a cloud write may be refused by Exchange Online or may
        # be undone by the next directory sync -- and which of the two happens
        # is not something the published reference settles. It is not disabled
        # for it: a refusal shows an error, and the on-premises route is one
        # switch away. What is not acceptable is a note claiming the write is
        # safe when nobody has checked.
        'Written with Set-Group. This group is mastered in Active Directory, so a cloud write here may be refused or undone by the next sync -- set Editing to On-premises to be sure it sticks.'
    } else {
        'Written with Set-Group, which behaves the same on-premises and in Exchange Online.'
    })
    $ovNotesNote.ForeColor = $(if (-not $canNotes) { (Get-ToolStatusColour -Kind Warn) }
                               elseif ($g.OnPrem) { (Get-ToolStatusColour -Kind Warn) }
                               elseif ($g.IsSynced -and $g.Kind -ne 'Unified') { (Get-ToolStatusColour -Kind Warn) }
                               else { (Get-ToolStatusColour -Kind Muted) })

    $all = @($gr.EmailAddresses | ForEach-Object { "$_" } | Where-Object { $_ })
    $smtpN = @($all | Where-Object { $_ -match '(?i)^smtp:' }).Count
    $x500N = @($all | Where-Object { $_ -match '(?i)^x500:' }).Count
    $ovAddrLine.Text = "$smtpN SMTP" + $(if ($x500N) { ", $x500N X500" }) + " -- primary $($gr.PrimarySmtpAddress). See the Addresses tab to change them."

    $f = New-Object System.Collections.ArrayList
    # OWNERLESS IS THE FINDING PEOPLE ACTUALLY CHASE. A group with no owner is
    # a real state and a bad one: nobody can be asked to approve a member,
    # nobody is told when it goes stale, and for a Microsoft 365 group the
    # expiry policy has nobody to renew it.
    # $null MEANS 'COULD NOT READ', EMPTY MEANS 'THERE ARE NONE'. Collapsing
    # the two asserts that a group has no owner when the owner read merely
    # failed -- which is the finding people act on.
    $owners = $null
    try { $owners = @(Get-GrpOwner) } catch { $owners = $null }
    if ($null -ne $owners -and @($owners).Count -eq 0) {
        [void]$f.Add('THIS GROUP HAS NO OWNER. Nobody can approve a membership request, nobody is asked before it is deleted, and nothing tells anyone when it goes stale. See Owners.')
    }
    if ($g.Kind -ne 'Dynamic') {
        $mc = $null
        try { $mc = @(Get-GrpMember).Count } catch { }
        if ($null -ne $mc) {
            if ($mc -eq 0)    { [void]$f.Add('The group has NO members. Mail sent to it goes nowhere. See Members.') }
            elseif ($mc -eq 1) { [void]$f.Add('The group has ONE member. That is often a list somebody outgrew -- worth asking whether it should still exist. See Members.') }
        }
    }
    # THE MAIL-FLOW FINDINGS COVER MICROSOFT 365 GROUPS NOW. They were skipped
    # while the Mail Flow tab refused that kind; leaving them skipped would
    # have meant the verdict stayed silent about an open M365 group that the
    # tab can now actually fix.
    if ($true) {
        $req = [bool]$gr.RequireSenderAuthenticationEnabled
        $accept = @($gr.AcceptMessagesOnlyFromSendersOrMembers)
        if (-not $req -and $accept.Count -gt 0) {
            [void]$f.Add("Sender authentication is OFF while $($accept.Count) allowed sender(s) are listed. The list is NOT being enforced -- the group is open while still looking restricted. See Mail Flow.")
        }
        if (-not $req) {
            [void]$f.Add('Anyone outside the organisation can send to this group. That is sometimes deliberate and is the usual route for spam to reach everybody at once. See Mail Flow.')
        }
    }
    if ($gr.HiddenFromAddressListsEnabled) {
        [void]$f.Add('Hidden from the address book. It still receives mail sent to its address.')
    }
    if ($g.IsSynced -and -not $g.OnPrem -and $g.Kind -ne 'Unified') {
        [void]$f.Add('This group is synced from Active Directory but this window is in cloud mode. Writes will be reverted by the next sync.')
    }

    Set-EditorVerdict -Findings @($f) -Box $ovVerdict `
        -Clean 'Nothing obviously wrong. It has an owner, it has members, and its mail-flow restrictions agree with each other.'
}
function Get-GrpSetCmdlet {
    <#
        The Set-* cmdlet for THIS group's kind.

        ONE PLACE, because the alternative is an if/else at every write site
        and one of them will be missed -- which is exactly what had happened:
        the hide-from-GAL and mail-flow handlers each carried their own
        two-way picker that knew about Dynamic and not about Unified, so a
        Microsoft 365 group was refused outright rather than routed.
    #>
    switch ($script:Grp.Kind) {
        'Unified' { 'Set-UnifiedGroup' }
        'Dynamic' { 'Set-DynamicDistributionGroup' }
        default   { 'Set-DistributionGroup' }
    }
}

function Get-GrpNotesCmdlet {
    <#
        The cmdlet that writes NOTES for this kind -- which is NOT the same
        list as Get-GrpSetCmdlet.

        Set-Group carries -Notes for distribution and mail-enabled security
        groups, and its own reference says flatly that it CANNOT modify
        dynamic distribution groups and to use Set-DynamicDistributionGroup
        instead. Meanwhile Set-DistributionGroup -- which Get-GrpSetCmdlet
        returns for those same kinds -- has no -Notes parameter at all. So the
        two pickers genuinely differ and sharing one would be wrong in both
        directions.
    #>
    switch ($script:Grp.Kind) {
        'Unified' { 'Set-UnifiedGroup' }
        'Dynamic' { 'Set-DynamicDistributionGroup' }
        default   { 'Set-Group' }
    }
}

function Add-GrpBypass {
    <#
        Add -BypassSecurityGroupManagerCheck, but ONLY where it is declared.

        Set-DistributionGroup and Set-Group declare it. Set-UnifiedGroup and
        Set-DynamicDistributionGroup DO NOT, and an undeclared parameter fails
        at BINDING -- before the call ever leaves the client, with an error
        naming the parameter rather than anything about the group. Without the
        switch, an operator who is not in the group's ManagedBy is refused; with
        it on the wrong cmdlet, everybody is.
    #>
    param([Parameter(Mandatory)][hashtable]$Parameters)
    if (@('Dynamic', 'Unified') -contains $script:Grp.Kind) { return $Parameters }
    $Parameters['BypassSecurityGroupManagerCheck'] = $true
    return $Parameters
}

$btnOvDesc.Add_Click({
    if (-not (Test-EditorLoaded)) { return }
    Invoke-EditorAction {
        $dn = "$($script:Grp.Dn)"
        if (-not $dn.Trim()) { Set-EditorStatus -Text 'There is no directory object to write to.' -Bad; return }
        $new = "$($txtOvDesc.Text)".Trim()
        $cur = Get-AdDescription -Dn $dn
        if (-not $cur.Ok) { Set-EditorStatus -Text "The description could not be read, so it is not being written: $($cur.Reason)" -Bad; return }
        if ($new -eq "$($cur.Text)".Trim()) { Set-EditorStatus -Text 'Nothing changed.'; return }
        Set-AdDescription -Dn $dn -Value $new
        Write-EditorAudit -Action 'GroupDescription' -Detail "Description: '$($cur.Text)' -> '$(if ($new) { $new } else { '(cleared)' })'"
        Update-OverviewTab
        Set-EditorStatus -Text ("Description written to Active Directory. " + $script:OnPremSyncNotice)
    } 'Apply group description'
})

$btnOvNotes.Add_Click({
    if (-not (Test-EditorLoaded)) { return }
    Invoke-EditorAction {
        if (-not (Test-GrpKind -Allow @('Distribution', 'Security', 'Unified', 'Dynamic') -What 'Editing the notes')) { return }
        $new = "$($txtOvNotes.Text)".Trim()
        $old = "$(Get-GrpNotes)".Trim()
        if ($new -eq $old) { Set-EditorStatus -Text 'Nothing changed.'; return }

        # AN EMPTY BOX CLEARS THE FIELD, and $null is how it is cleared. No
        # reference page states how to clear either Notes parameter, so this
        # is the Exchange convention rather than a documented behaviour -- if
        # a build ever refuses it, the error surfaces rather than the clear
        # silently doing nothing.
        $value = $(if ($new) { $new } else { $null })

        # -BypassSecurityGroupManagerCheck is added only where the cmdlet
        # declares it -- Set-Group does, Set-UnifiedGroup and
        # Set-DynamicDistributionGroup do not, and an undeclared parameter
        # fails at binding. Without it on Set-Group, a mail-enabled security
        # group refuses an operator who is not in its ManagedBy.
        $np = Add-GrpBypass -Parameters @{
            Identity = $script:Grp.Smtp; Notes = $value; Confirm = $false; ErrorAction = 'Stop' }
        if ($script:Grp.Kind -eq 'Unified') {
            # ALWAYS CLOUD. There is no on-premises Set-UnifiedGroup.
            Invoke-EXOCommand -Name 'Set-UnifiedGroup' -Parameters $np | Out-Null
        } else {
            Invoke-GrpCmd -Name (Get-GrpNotesCmdlet) -Parameters $np | Out-Null
        }

        # THE TEXT ITSELF IS NOT LOGGED IN FULL. Who changed it and roughly to
        # what is the useful audit row; a paragraph of free text in a CSV
        # column is not.
        $shown = $(if ($new) { $(if ($new.Length -gt 60) { $new.Substring(0, 60) + '...' } else { $new }) } else { '(cleared)' })
        Write-EditorAudit -Action 'GroupNotes' -Detail "Notes set to: $shown"
        $script:Grp = Resolve-GroupTarget -Identity $script:Grp.Smtp -ForceOnPrem:($script:Mode -eq 'OnPrem')
        Update-OverviewTab
        Set-EditorStatus -Text ($(if ($new) { 'Notes updated.' } else { 'Notes cleared.' }) +
                             $(if ($script:Grp.OnPrem) { " $($script:OnPremSyncNotice)" }))
    } 'Apply group notes'
})

$btnOvHide.Add_Click({
    if (-not (Test-EditorLoaded)) { return }
    Invoke-EditorAction {
        if (-not (Test-GrpKind -Allow @('Distribution','Security','Dynamic','Unified') -What 'Hiding from the address book')) { return }
        $want = ("$($cmbOvHide.SelectedItem)" -eq 'True')
        if ($want -eq [bool]$script:Grp.Raw.HiddenFromAddressListsEnabled) { Set-EditorStatus -Text 'Nothing changed.'; return }
        $p = Add-GrpBypass -Parameters @{ Identity = $script:Grp.Smtp; HiddenFromAddressListsEnabled = $want; Confirm = $false; ErrorAction = 'Stop' }
        Invoke-GrpCmd -Name (Get-GrpSetCmdlet) -Parameters $p | Out-Null
        Write-EditorAudit -Action 'GroupHideFromGal' -Detail "Hidden from address list = $want."
        $script:Grp = Resolve-GroupTarget -Identity $script:Grp.Smtp -ForceOnPrem:($script:Mode -eq 'OnPrem')
        Update-OverviewTab
        $script:Loaded['MailFlow'] = $false
        Set-EditorStatus -Text ($(if ($want) { 'Hidden from the address book.' } else { 'Visible in the address book.' }) +
                             $(if ($script:Grp.OnPrem) { " $($script:OnPremSyncNotice)" }))
    } 'Apply address book visibility'
})
#endregion

#region Owners tab --------------------------------------------------------------
<#
    WHO OWNS IT -- AND THE TRAP UNDERNEATH.

    ManagedBy IS REPLACED WHOLE. Set-DistributionGroup -ManagedBy does not add
    to the list, it overwrites it, and getting that wrong does not error -- it
    silently removes everybody else. So every Apply on this tab writes the
    ENTIRE owner list back, built from the grid, and adding one person means
    writing the other four again.

    A MICROSOFT 365 GROUP IS THE EXCEPTION. Its owners are links, added and
    removed one at a time with Add-/Remove-UnifiedGroupLinks, and
    *-DistributionGroup refuses it outright with "not supported on
    GroupMailbox".

    AN OWNER THAT WILL NOT RESOLVE IS SHOWN, NOT DROPPED. A deleted account
    still occupies a slot in ManagedBy, and a tool that quietly left it out of
    the rewrite would be removing it without being asked.
#>
$owY = 8
[void](New-TabLabel $tabOwners 'OWNERS' 8 $owY -Bold)
$owY += 22
$owNote = New-TabLabel $tabOwners '' 8 $owY 1040 -Muted
$owNote.Size = New-Object System.Drawing.Size(1040, 32)
$owY += 40
$gridOwners = New-TabGrid $tabOwners @(@('Name', 380), @('Address', 300), @('State', 180)) 8 $owY 700 320
Add-GridPickColumn -Grid $gridOwners
$owBtnY = $owY
$btnOwAdd    = New-TabButton $tabOwners 'Add owners...'  720 $owBtnY 170
$owBtnY += 34
$btnOwRemove = New-TabButton $tabOwners 'Remove ticked'  720 $owBtnY 170
$owBtnY += 34
$btnOwAll    = New-TabButton $tabOwners 'Tick all'       720 $owBtnY 82
$btnOwNone   = New-TabButton $tabOwners 'None'           808 $owBtnY 82
$owY += 332
$owHint = New-TabLabel $tabOwners '' 8 $owY 1040 -Muted
$owHint.Size = New-Object System.Drawing.Size(1040, 46)
$owHint.Text = ('For a distribution list the whole owner list is rewritten on every change -- that is how Exchange stores it, and it is why removing one owner is not a one-line operation.' + "`r`n" +
                'A group with no owner is allowed and is almost always a mistake.')

function Get-GrpOwner {
    # The owners, whichever family this group belongs to.
    $g = $script:Grp
    if ($g.Kind -eq 'Unified') {
        return @(Invoke-EXOCommand -Name 'Get-UnifiedGroupLinks' -Parameters @{
                    Identity = $g.Smtp; LinkType = 'Owners'; ResultSize = 'Unlimited'; ErrorAction = 'Stop' })
    }
    # ManagedBy holds directory names, not addresses; each is re-resolved so
    # the grid can show a person rather than a CN.
    $out = @()
    foreach ($o in @($g.Raw.ManagedBy)) { $out += "$o" }
    return $out
}

function Update-OwnersTab {
    $gridOwners.Rows.Clear()
    $g = $script:Grp
    $raw = @()
    try { $raw = @(Get-GrpOwner) } catch {
        $script:TabReadFailed = $true
        $owNote.Text = "The owners could not be read: $($_.Exception.Message)"
        $owNote.ForeColor = (Get-ToolStatusColour -Kind Bad)
        return
    }

    foreach ($o in $raw) {
        if ($g.Kind -eq 'Unified') {
            $i = $gridOwners.Rows.Add($false, "$($o.DisplayName)", "$($o.PrimarySmtpAddress)", 'ok')
            $gridOwners.Rows[$i].Tag = [PSCustomObject]@{ Ok = $true; Name = "$($o.DisplayName)"; Address = "$($o.PrimarySmtpAddress)"; Raw = "$($o.PrimarySmtpAddress)" }
        } else {
            $res = Resolve-GrpRecipient -Entry "$o"
            $state = $(if ($res.Ok) { 'ok' } else { "could not be re-resolved -- may be deleted" })
            $i = $gridOwners.Rows.Add($false, $(if ($res.Ok) { $res.Name } else { "$o" }), $res.Address, $state)
            $gridOwners.Rows[$i].Tag = [PSCustomObject]@{
                Ok = $res.Ok; Name = $res.Name; Address = $res.Address; Raw = "$o"
            }
            if (-not $res.Ok) { $gridOwners.Rows[$i].DefaultCellStyle.ForeColor = (Get-ToolStatusColour -Kind Warn) }
        }
    }

    if ($gridOwners.Rows.Count -eq 0) {
        $owNote.Text = 'THIS GROUP HAS NO OWNER. Nobody can approve a membership request and nothing tells anyone when it goes stale.'
        $owNote.ForeColor = (Get-ToolStatusColour -Kind Bad)
    } elseif ($g.Kind -eq 'Unified') {
        $owNote.Text = "$($gridOwners.Rows.Count) owner(s). Added and removed one at a time -- a Microsoft 365 group stores them as links."
        $owNote.ForeColor = (Get-ToolStatusColour -Kind Muted)
    } else {
        $owNote.Text = "$($gridOwners.Rows.Count) owner(s). The whole list is rewritten on every change, so an owner shown in amber is carried through unchanged rather than dropped."
        $owNote.ForeColor = (Get-ToolStatusColour -Kind Muted)
    }
}

function Set-GrpOwnerList {
    # THE WHOLE LIST, ALWAYS. -BypassSecurityGroupManagerCheck because
    # Exchange checks whether YOU are in the group's ManagedBy regardless of
    # what your RBAC role says -- an administrator who is not an owner is
    # refused without it, with an error that reads like a permissions problem
    # and is one only in the narrowest sense.
    param([string[]]$Owners)
    Invoke-GrpCmd -Name 'Set-DistributionGroup' -Parameters @{
        Identity = $script:Grp.Smtp
        ManagedBy = @($Owners)
        BypassSecurityGroupManagerCheck = $true
        Confirm = $false
        ErrorAction = 'Stop'
    } | Out-Null
}

$btnOwAll.Add_Click({  Set-GridPicked -Grid $gridOwners -On $true })
$btnOwNone.Add_Click({ Set-GridPicked -Grid $gridOwners -On $false })

$btnOwAdd.Add_Click({
    if (-not (Test-EditorLoaded)) { return }
    Invoke-EditorAction {
        if (-not (Test-GrpKind -Allow @('Distribution','Security','Unified') -What 'Editing owners')) { return }
        $who = Show-InputListDialog -Title 'Add owners' -Width 620 `
                -Prompt 'Who should own this group? One per line. first.last is enough -- the mail domain is added for you.'
        $list = ConvertFrom-DialogList -Text "$who" -CompleteDomain
        if ($list.Count -eq 0) { return }

        $resolved = @()
        foreach ($w in $list) {
            $r = Resolve-GrpRecipient -Entry $w
            if (-not $r.Ok) { Set-EditorStatus -Text "'$w' $($r.Reason). Nothing was changed." -Bad; return }
            $resolved += $r
        }

        if ($script:Grp.Kind -eq 'Unified') {
            $lines = @(); $ok = 0; $bad = 0
            foreach ($r in $resolved) {
                try {
                    Invoke-EXOCommand -Name 'Add-UnifiedGroupLinks' -Parameters @{
                        Identity = $script:Grp.Smtp; LinkType = 'Owners'; Links = $r.Address
                        Confirm = $false; ErrorAction = 'Stop' } | Out-Null
                    $lines += "OK      $($r.Name)"; $ok++
                } catch { $lines += "FAILED  $($r.Name): $($_.Exception.Message)"; $bad++ }
            }
            Write-EditorAudit -Action 'GroupOwnerAdd' -Result $(if ($bad -and $ok) { 'Partial' } elseif ($bad) { 'Failed' } else { 'Success' }) `
                -Detail "added owners: $(($resolved | ForEach-Object { $_.Address }) -join '; ')"
            if ($bad) { Show-ResultListDialog -Title "Add owners -- $ok done, $bad failed" -Lines $lines }
        } else {
            # EVERY EXISTING OWNER IS WRITTEN BACK WITH THE NEW ONES.
            $all = @()
            foreach ($row in $gridOwners.Rows) { if ($row.Tag) { $all += "$(if ($row.Tag.Address) { $row.Tag.Address } else { $row.Tag.Raw })" } }
            foreach ($r in $resolved) { if ($all -notcontains $r.Address) { $all += $r.Address } }
            $a = Show-ToolDialog(
                ("Set the owners of $($script:Grp.Display) to:" + "`r`n`r`n  " + ($all -join "`r`n  ") + "`r`n`r`n" +
                 'The whole owner list is rewritten -- that is how Exchange stores it.'),
                'Set owners', 'OKCancel', 'Warning')
            if ($a -ne [System.Windows.Forms.DialogResult]::OK) { return }
            Set-GrpOwnerList -Owners $all
            Write-EditorAudit -Action 'GroupOwnerSet' -Detail "ManagedBy = $($all -join '; ')"
        }
        $script:Grp = Resolve-GroupTarget -Identity $script:Grp.Smtp -ForceOnPrem:($script:Mode -eq 'OnPrem')
        Update-OwnersTab
        $script:Loaded['Overview'] = $false
        Set-EditorStatus -Text 'Owners applied.'
    } 'Add owners'
})

$btnOwRemove.Add_Click({
    if (-not (Test-EditorLoaded)) { return }
    Invoke-EditorAction {
        if (-not (Test-GrpKind -Allow @('Distribution','Security','Unified') -What 'Editing owners')) { return }
        $picked = Get-GridPicked -Grid $gridOwners
        if ($picked.Count -eq 0) { Set-EditorStatus -Text 'Tick one or more owners to remove.' -Bad; return }

        $keep = @()
        foreach ($row in $gridOwners.Rows) {
            if ([bool]$row.Cells['Pick'].Value) { continue }
            if ($row.Tag) { $keep += "$(if ($row.Tag.Address) { $row.Tag.Address } else { $row.Tag.Raw })" }
        }
        $warn = ''
        if ($keep.Count -eq 0) {
            $warn = "`r`n`r`nTHIS REMOVES THE LAST OWNER. A group with no owner is a real state and a bad one: nobody can approve a membership request, and nothing tells anyone when it goes stale."
        }
        $a = Show-ToolDialog(
            ("Remove $($picked.Count) owner(s) from $($script:Grp.Display)?" + "`r`n`r`n  " +
             (@($picked | ForEach-Object { $_.Name }) -join "`r`n  ") + $warn),
            'Remove owners', 'OKCancel', 'Warning')
        if ($a -ne [System.Windows.Forms.DialogResult]::OK) { return }

        if ($script:Grp.Kind -eq 'Unified') {
            $lines = @(); $ok = 0; $bad = 0
            foreach ($e in $picked) {
                try {
                    Invoke-EXOCommand -Name 'Remove-UnifiedGroupLinks' -Parameters @{
                        Identity = $script:Grp.Smtp; LinkType = 'Owners'; Links = $e.Address
                        Confirm = $false; ErrorAction = 'Stop' } | Out-Null
                    $lines += "OK      $($e.Name)"; $ok++
                } catch { $lines += "FAILED  $($e.Name): $($_.Exception.Message)"; $bad++ }
            }
            Write-EditorAudit -Action 'GroupOwnerRemove' -Result $(if ($bad -and $ok) { 'Partial' } elseif ($bad) { 'Failed' } else { 'Success' }) `
                -Detail "removed owners: $(($picked | ForEach-Object { $_.Address }) -join '; ')"
            if ($bad) { Show-ResultListDialog -Title "Remove owners -- $ok done, $bad failed" -Lines $lines }
        } else {
            Set-GrpOwnerList -Owners $keep
            Write-EditorAudit -Action 'GroupOwnerSet' -Detail "ManagedBy = $(if ($keep) { $keep -join '; ' } else { '(none)' })"
        }
        $script:Grp = Resolve-GroupTarget -Identity $script:Grp.Smtp -ForceOnPrem:($script:Mode -eq 'OnPrem')
        Update-OwnersTab
        $script:Loaded['Overview'] = $false
        Set-EditorStatus -Text "Removed $($picked.Count) owner(s)."
    } 'Remove owners'
})
#endregion

#region Members tab -------------------------------------------------------------
<#
    WHO IS IN IT.

    -ResultSize Unlimited IS LOAD-BEARING. The default is 1000 and it
    truncates SILENTLY -- a group with 1,400 members shows 1,000, and a tool
    that then "removes everyone not in the grid" removes four hundred people
    it never saw.

    ADDS BEFORE REMOVALS, always. A run that fails halfway leaves the group
    with too many members rather than too few, which is the safer way to be
    wrong: nobody loses mail while it is put right.

    A DYNAMIC GROUP HAS NO MEMBER LIST. Its membership is a filter evaluated
    when mail arrives. The filter is shown here, and the preview is what it
    resolves to right now -- not a list anybody can edit.
#>
$mbY = 8
[void](New-TabLabel $tabMembers 'MEMBERS' 8 $mbY -Bold)
$mbY += 22
$mbNote = New-TabLabel $tabMembers '' 8 $mbY 1040 -Muted
$mbNote.Size = New-Object System.Drawing.Size(1040, 32)
$mbY += 40
$gridMembers = New-TabGrid $tabMembers @(@('Name', 360), @('Address', 300), @('Type', 160)) 8 $mbY 700 330
Add-GridPickColumn -Grid $gridMembers
$mbBtnY = $mbY
$btnMbAdd    = New-TabButton $tabMembers 'Add members...' 720 $mbBtnY 170
$mbBtnY += 34
$btnMbRemove = New-TabButton $tabMembers 'Remove ticked'  720 $mbBtnY 170
$mbBtnY += 34
$btnMbAll    = New-TabButton $tabMembers 'Tick all'       720 $mbBtnY 82
$btnMbNone   = New-TabButton $tabMembers 'None'           808 $mbBtnY 82
$mbBtnY += 34
# SEND AS FROM THE MEMBER LIST (2026-09-25). 'Everyone in the group can send
# as the group' is the common request, and the member list is already on
# screen with tick boxes -- retyping it on the Send As tab was the slow part.
# Same write, same checks, same results window as that tab: both buttons call
# Invoke-GrpSendAsGrantList.
$btnMbSendAs = New-TabButton $tabMembers 'Grant Send As to ticked' 720 $mbBtnY 170
$mbBtnY += 42
$btnMbRefresh = New-TabButton $tabMembers 'Refresh'       720 $mbBtnY 170
$mbY += 342
$mbFilter = New-TabLabel $tabMembers '' 8 $mbY 1040 -Muted
$mbFilter.Size = New-Object System.Drawing.Size(1040, 64)

function Get-GrpMember {
    $g = $script:Grp
    switch ($g.Kind) {
        'Unified' {
            return @(Invoke-EXOCommand -Name 'Get-UnifiedGroupLinks' -Parameters @{
                        Identity = $g.Smtp; LinkType = 'Members'; ResultSize = 'Unlimited'; ErrorAction = 'Stop' })
        }
        'Dynamic' {
            # THE PREVIEW NEEDS THE CONTAINER AS WELL AS THE FILTER. Without
            # -OrganizationalUnit the preview can include recipients the group
            # would never actually deliver to.
            $p = @{ RecipientPreviewFilter = "$($g.Raw.RecipientFilter)"; ResultSize = 'Unlimited'; ErrorAction = 'Stop' }
            if ("$($g.Raw.RecipientContainer)".Trim()) { $p['OrganizationalUnit'] = "$($g.Raw.RecipientContainer)" }
            return @(Invoke-GrpCmd -Name 'Get-Recipient' -Parameters $p)
        }
        default {
            return @(Invoke-GrpCmd -Name 'Get-DistributionGroupMember' -Parameters @{
                        Identity = $g.Smtp; ResultSize = 'Unlimited'; ErrorAction = 'Stop' })
        }
    }
}

function Update-MembersTab {
    $gridMembers.Rows.Clear()
    $g = $script:Grp
    $mem = @()
    try { $mem = @(Get-GrpMember) } catch {
        $script:TabReadFailed = $true
        $mbNote.Text = "The members could not be read: $($_.Exception.Message)"
        $mbNote.ForeColor = (Get-ToolStatusColour -Kind Bad)
        return
    }
    foreach ($m in $mem) {
        $i = $gridMembers.Rows.Add($false, "$($m.DisplayName)", "$($m.PrimarySmtpAddress)", "$($m.RecipientTypeDetails)")
        $gridMembers.Rows[$i].Tag = [PSCustomObject]@{
            Name = "$($m.DisplayName)"; Address = "$($m.PrimarySmtpAddress)"; Type = "$($m.RecipientTypeDetails)"
            # Carried for 'Grant Send As to ticked': the on-premises write
            # needs it, and on-premises member reads already return it.
            Sam = "$($m.SamAccountName)"
        }
        if ("$($m.RecipientTypeDetails)" -match '(?i)Group') {
            # A nested group is worth seeing at a glance: it is where "who
            # actually gets this mail" stops being answerable from one screen.
            $gridMembers.Rows[$i].DefaultCellStyle.ForeColor = [System.Drawing.Color]::FromArgb(0, 90, 150)
        }
    }

    # AN EMPTY LIST ON-PREMISES IS CHECKED AGAINST THE CLOUD before it is
    # believed. Zero members and 'the read could not see them' look identical
    # in a grid, and the second one is a scope problem the operator can do
    # something about -- but only if the window says so.
    if ($g.OnPrem -and $g.Kind -ne 'Dynamic' -and $gridMembers.Rows.Count -eq 0) {
        $cloudCount = $null
        try {
            $cloudCount = @(Invoke-EXOCommand -Name 'Get-DistributionGroupMember' -Parameters @{
                                Identity = $g.Smtp; ResultSize = 'Unlimited'; ErrorAction = 'Stop' }).Count
        } catch { }
        if ($null -ne $cloudCount -and $cloudCount -gt 0) {
            $script:TabReadFailed = $true
            $mbNote.Text = "THE ON-PREMISES READ RETURNED NO MEMBERS, but the cloud copy of this group has $cloudCount. That is a directory scope problem, not an empty group -- $(if ($script:DCDetail) { $script:DCDetail } else { 'no scope detail' })."
            $mbNote.ForeColor = (Get-ToolStatusColour -Kind Bad)
            $mbFilter.Text = ('The session is put forest-wide on every load, and the controller is chosen from the group''s own distinguished name. If this persists, the group''s domain may not be listed in Tenant.json -- check Directories.' + "`r`n" +
                              'Switch Editing to Cloud to see and change the membership there, remembering that a cloud write to a synced group is undone by the next sync.')
            $btnMbAdd.Enabled = $false; $btnMbRemove.Enabled = $false; $btnMbSendAs.Enabled = $false
            return
        }
    }

    if ($g.Kind -eq 'Dynamic') {
        $btnMbAdd.Enabled = $false; $btnMbRemove.Enabled = $false; $btnMbSendAs.Enabled = $false
        $mbNote.Text = "$($gridMembers.Rows.Count) recipient(s) match the filter RIGHT NOW. This is a preview, not a list -- it is recalculated every time mail arrives, so it can be different tomorrow without anybody changing anything."
        $mbNote.ForeColor = (Get-ToolStatusColour -Kind Warn)
        $mbFilter.Text = ("Filter: $($g.Raw.RecipientFilter)" + "`r`n" +
                          "Container: $(if ("$($g.Raw.RecipientContainer)") { $g.Raw.RecipientContainer } else { '(the whole directory)' })" + "`r`n" +
                          'To change who is in this group, change the filter -- which is not something this window does, because a bad filter silently empties a distribution list.')
    } else {
        $btnMbAdd.Enabled = $true; $btnMbRemove.Enabled = $true
        # Same kinds the Send As tab's own grant accepts.
        $btnMbSendAs.Enabled = (@('Distribution', 'Security') -contains $g.Kind)
        $nested = @($gridMembers.Rows | Where-Object { $_.Tag -and "$($_.Tag.Type)" -match '(?i)Group' }).Count
        $mbNote.Text = "$($gridMembers.Rows.Count) member(s)$(if ($nested) { ", $nested of them nested groups (shown in blue)" })."
        $mbNote.ForeColor = (Get-ToolStatusColour -Kind Muted)
        $mbFilter.Text = 'Every member is read, never the first thousand -- the default page size truncates silently and a partial list is how people get removed from groups they were never seen in.'
    }
}

$btnMbAll.Add_Click({  Set-GridPicked -Grid $gridMembers -On $true })

$btnMbSendAs.Add_Click({
    if (-not (Test-EditorLoaded)) { return }
    Invoke-EditorAction {
        if (-not (Test-GrpKind -Allow @('Distribution','Security') -What 'Send As')) { return }
        $picked = Get-GridPicked -Grid $gridMembers
        if ($picked.Count -eq 0) { Set-EditorStatus -Text 'Tick the members who should get Send As (Tick all selects everyone).' -Bad; return }

        # The row already carries what the write needs. Only a row missing
        # its sAMAccountName on-premises is looked up again.
        $resolved = @(); $skipped = @()
        foreach ($e in $picked) {
            if ($script:Grp.OnPrem -and -not "$($e.Sam)".Trim()) {
                $r = Resolve-GrpRecipient -Entry $(if ("$($e.Address)".Trim()) { $e.Address } else { $e.Name })
                if (-not $r.Ok) { $skipped += "$($e.Name): $($r.Reason)"; continue }
                if (-not "$($r.Sam)".Trim()) { $skipped += "$($e.Name): no sAMAccountName, which the on-premises Send As permission needs"; continue }
                $resolved += $r
                continue
            }
            if (-not $script:Grp.OnPrem -and -not "$($e.Address)".Trim()) { $skipped += "$($e.Name): no address to grant to"; continue }
            $resolved += [PSCustomObject]@{ Ok = $true; Name = "$($e.Name)"; Address = "$($e.Address)"; Sam = "$($e.Sam)"; Type = "$($e.Type)" }
        }
        Invoke-GrpSendAsGrantList -Resolved $resolved -Skipped $skipped
    } 'Grant Send As to ticked members'
})
$btnMbNone.Add_Click({ Set-GridPicked -Grid $gridMembers -On $false })
$btnMbRefresh.Add_Click({
    if (-not (Test-EditorLoaded)) { return }
    Invoke-EditorAction { Update-MembersTab; Set-EditorStatus -Text 'Members re-read.' } 'Refresh members'
})

$btnMbAdd.Add_Click({
    if (-not (Test-EditorLoaded)) { return }
    Invoke-EditorAction {
        if (-not (Test-GrpKind -Allow @('Distribution','Security','Unified') -What 'Adding members')) { return }
        $who = Show-InputListDialog -Title 'Add members' -Width 620 `
                -Prompt 'Who should be in this group? One per line -- addresses, aliases or group names.'
        $list = ConvertFrom-DialogList -Text "$who"
        if ($list.Count -eq 0) { return }

        $resolved = @()
        foreach ($w in $list) {
            $r = Resolve-GrpRecipient -Entry $w
            if (-not $r.Ok) { Set-EditorStatus -Text "'$w' $($r.Reason). Nothing was changed." -Bad; return }
            $resolved += $r
        }
        $a = Show-ToolDialog(("Add $($resolved.Count) member(s) to $($script:Grp.Display)?" + "`r`n`r`n  " +
                              (@($resolved | ForEach-Object { $_.Name }) -join "`r`n  ")),
                             'Add members', 'OKCancel', 'Question')
        if ($a -ne [System.Windows.Forms.DialogResult]::OK) { return }

        $lines = @(); $ok = 0; $bad = 0
        foreach ($r in $resolved) {
            try {
                if ($script:Grp.Kind -eq 'Unified') {
                    Invoke-EXOCommand -Name 'Add-UnifiedGroupLinks' -Parameters @{
                        Identity = $script:Grp.Smtp; LinkType = 'Members'; Links = $r.Address
                        Confirm = $false; ErrorAction = 'Stop' } | Out-Null
                } else {
                    Invoke-GrpCmd -Name 'Add-DistributionGroupMember' -Parameters @{
                        Identity = $script:Grp.Smtp; Member = $r.Address
                        BypassSecurityGroupManagerCheck = $true; Confirm = $false; ErrorAction = 'Stop' } | Out-Null
                }
                $lines += "OK      $($r.Name)"; $ok++
            } catch {
                # ALREADY A MEMBER IS NOT A FAILURE. It is the answer to the
                # question, and reporting it as an error makes people stop
                # reading the result list.
                if ($_.Exception.Message -match '(?i)already a member') { $lines += "SKIP    $($r.Name) is already a member"; $ok++ }
                else { $lines += "FAILED  $($r.Name): $($_.Exception.Message)"; $bad++ }
            }
        }
        Write-EditorAudit -Action 'GroupMemberAdd' -Result $(if ($bad -and $ok) { 'Partial' } elseif ($bad) { 'Failed' } else { 'Success' }) `
            -Detail "added: $(($resolved | ForEach-Object { $_.Address }) -join '; ')"
        Show-ResultListDialog -Title "Add members -- $ok done, $bad failed" -Lines $lines
        Update-MembersTab
        $script:Loaded['Overview'] = $false
        Set-EditorStatus -Text "Added $ok, failed $bad." -Bad:($bad -gt 0)
    } 'Add members'
})

$btnMbRemove.Add_Click({
    if (-not (Test-EditorLoaded)) { return }
    Invoke-EditorAction {
        if (-not (Test-GrpKind -Allow @('Distribution','Security','Unified') -What 'Removing members')) { return }
        $picked = Get-GridPicked -Grid $gridMembers
        if ($picked.Count -eq 0) { Set-EditorStatus -Text 'Tick one or more members to remove.' -Bad; return }
        $a = Show-ToolDialog(("Remove $($picked.Count) member(s) from $($script:Grp.Display)?" + "`r`n`r`n  " +
                              (@($picked | ForEach-Object { $_.Name }) -join "`r`n  ") + "`r`n`r`n" +
                              'They stop receiving anything sent to this group.'),
                             'Remove members', 'OKCancel', 'Warning')
        if ($a -ne [System.Windows.Forms.DialogResult]::OK) { return }

        $lines = @(); $ok = 0; $bad = 0
        foreach ($e in $picked) {
            try {
                if ($script:Grp.Kind -eq 'Unified') {
                    Invoke-EXOCommand -Name 'Remove-UnifiedGroupLinks' -Parameters @{
                        Identity = $script:Grp.Smtp; LinkType = 'Members'; Links = $e.Address
                        Confirm = $false; ErrorAction = 'Stop' } | Out-Null
                } else {
                    Invoke-GrpCmd -Name 'Remove-DistributionGroupMember' -Parameters @{
                        Identity = $script:Grp.Smtp; Member = $e.Address
                        BypassSecurityGroupManagerCheck = $true; Confirm = $false; ErrorAction = 'Stop' } | Out-Null
                }
                $lines += "OK      $($e.Name)"; $ok++
            } catch {
                if ($_.Exception.Message -match '(?i)not a member') { $lines += "SKIP    $($e.Name) was not a member"; $ok++ }
                else { $lines += "FAILED  $($e.Name): $($_.Exception.Message)"; $bad++ }
            }
        }
        Write-EditorAudit -Action 'GroupMemberRemove' -Result $(if ($bad -and $ok) { 'Partial' } elseif ($bad) { 'Failed' } else { 'Success' }) `
            -Detail "removed: $(($picked | ForEach-Object { $_.Address }) -join '; ')"
        Show-ResultListDialog -Title "Remove members -- $ok done, $bad failed" -Lines $lines
        Update-MembersTab
        $script:Loaded['Overview'] = $false
        Set-EditorStatus -Text "Removed $ok, failed $bad." -Bad:($bad -gt 0)
    } 'Remove members'
})
#endregion

#region Mail Flow tab -----------------------------------------------------------
<#
    WHO MAY SEND TO IT, AND WHETHER THE RULE IS BEING ENFORCED.

    SENDER AUTHENTICATION AND THE ALLOWED-SENDERS LIST ARE ON ONE TAB,
    deliberately. Turning sender authentication OFF does not clear the list --
    it stops the list being ENFORCED. The group goes from restricted to open
    while still LOOKING restricted in the portal, and the two being edited in
    different places is how that goes unnoticed.

    AcceptMessagesOnlyFromSendersOrMembers IS REPLACED WHOLE, like ManagedBy.
    Adding one allowed sender means writing all the others back, and getting
    that wrong does not error.
#>
$mfY = 8
[void](New-TabLabel $tabMailFlow 'WHO MAY SEND TO THIS GROUP' 8 $mfY -Bold)
$mfY += 24
$chkRequireAuth = New-Object System.Windows.Forms.CheckBox
$chkRequireAuth.Location = New-Object System.Drawing.Point(8, $mfY)
$chkRequireAuth.Size     = New-Object System.Drawing.Size(700, 20)
$chkRequireAuth.Text     = 'Only authenticated senders (untick to let EXTERNAL senders post to this group)'
$tabMailFlow.Controls.Add($chkRequireAuth)
$mfY += 26
# HIDE-FROM-GAL IS NOT HERE. It used to sit below as a disabled echo pointing
# at the Overview tab, which was a control that could not be used and a
# sentence telling you to go elsewhere -- two costs for no benefit. Overview
# is the one place it lives, in all three editors.
$btnMfApply = New-TabButton $tabMailFlow 'Apply' 8 $mfY 170
$mfY += 34
$mfWarn = New-TabLabel $tabMailFlow '' 8 $mfY 1040 -Muted
$mfWarn.Size = New-Object System.Drawing.Size(1040, 48)
$mfY += 56

[void](New-TabLabel $tabMailFlow 'ALLOWED SENDERS' 8 $mfY -Bold)
$mfY += 22
$gridAllowed = New-TabGrid $tabMailFlow @(@('Name', 360), @('Address', 300), @('State', 160)) 8 $mfY 700 250
Add-GridPickColumn -Grid $gridAllowed
$mfBtnY = $mfY
$btnAlAdd    = New-TabButton $tabMailFlow 'Add senders...' 720 $mfBtnY 170
$mfBtnY += 34
$btnAlRemove = New-TabButton $tabMailFlow 'Remove ticked'  720 $mfBtnY 170
$mfBtnY += 34
$btnAlAll    = New-TabButton $tabMailFlow 'Tick all'       720 $mfBtnY 82
$btnAlNone   = New-TabButton $tabMailFlow 'None'           808 $mfBtnY 82
$mfY += 262
$mfNote = New-TabLabel $tabMailFlow '' 8 $mfY 1040 -Muted
$mfNote.Size = New-Object System.Drawing.Size(1040, 48)
$mfNote.Text = ('An EMPTY list means anybody may send, subject to the authentication setting above. A populated list means only those senders -- and only while authentication is required.' + "`r`n" +
                'The whole list is rewritten on every change, so a sender shown in amber is carried through unchanged rather than dropped.')

function Update-MailFlowTab {
    $g = $script:Grp
    # A MICROSOFT 365 GROUP IS NOT REFUSED HERE ANY MORE. The old block said
    # these settings 'are not edited with the distribution-group cmdlets' --
    # true, and beside the point: Set-UnifiedGroup declares both
    # -RequireSenderAuthenticationEnabled and
    # -AcceptMessagesOnlyFromSendersOrMembers, Applicable to Exchange Online.
    # The tab routes by kind now instead of switching itself off, which
    # matters most in a cloud-only tenant where M365 groups are most of them.
    $chkRequireAuth.Enabled = $true
    $btnMfApply.Enabled = $true; $btnAlAdd.Enabled = $true; $btnAlRemove.Enabled = $true

    $gr = $g.Raw
    $chkRequireAuth.Checked = [bool]$gr.RequireSenderAuthenticationEnabled

    $gridAllowed.Rows.Clear()
    foreach ($a in @($gr.AcceptMessagesOnlyFromSendersOrMembers)) {
        $res = Resolve-GrpRecipient -Entry "$a"
        $i = $gridAllowed.Rows.Add($false, $(if ($res.Ok) { $res.Name } else { "$a" }), $res.Address,
                                   $(if ($res.Ok) { 'ok' } else { 'could not be re-resolved' }))
        $gridAllowed.Rows[$i].Tag = [PSCustomObject]@{ Ok = $res.Ok; Name = $res.Name; Address = $res.Address; Raw = "$a" }
        if (-not $res.Ok) { $gridAllowed.Rows[$i].DefaultCellStyle.ForeColor = (Get-ToolStatusColour -Kind Warn) }
    }

    # THE PAIRED WARNING, EVERY TIME THE TAB IS DRAWN.
    if (-not $chkRequireAuth.Checked -and $gridAllowed.Rows.Count -gt 0) {
        $mfWarn.Text = "THE $($gridAllowed.Rows.Count) ALLOWED SENDER(S) BELOW ARE NOT BEING ENFORCED. Sender authentication is off, so anyone -- inside or outside -- can post to this group, while it still looks restricted."
        $mfWarn.ForeColor = (Get-ToolStatusColour -Kind Bad)
    } elseif (-not $chkRequireAuth.Checked) {
        $mfWarn.Text = 'Sender authentication is OFF: anyone outside the organisation can send to this group. Sometimes deliberate, and the usual route for spam to reach everybody at once.'
        $mfWarn.ForeColor = (Get-ToolStatusColour -Kind Warn)
    } else {
        $mfWarn.Text = 'Only authenticated senders may post. The allowed-senders list below narrows that further when it is not empty.'
        $mfWarn.ForeColor = (Get-ToolStatusColour -Kind Muted)
    }
}

function Set-GrpAllowedSenders {
    # ROUTED BY KIND, like every other write on this tab. Hardcoding
    # Set-DistributionGroup here would have failed on a Microsoft 365 group the
    # moment the tab stopped refusing them, and on a dynamic group it would
    # have failed on the bypass switch before that.
    param([string[]]$Senders)
    $p = Add-GrpBypass -Parameters @{
        Identity = $script:Grp.Smtp
        AcceptMessagesOnlyFromSendersOrMembers = @($Senders)
        Confirm = $false
        ErrorAction = 'Stop'
    }
    Invoke-GrpCmd -Name (Get-GrpSetCmdlet) -Parameters $p | Out-Null
}

$btnAlAll.Add_Click({  Set-GridPicked -Grid $gridAllowed -On $true })
$btnAlNone.Add_Click({ Set-GridPicked -Grid $gridAllowed -On $false })

$btnMfApply.Add_Click({
    if (-not (Test-EditorLoaded)) { return }
    Invoke-EditorAction {
        if (-not (Test-GrpKind -Allow @('Distribution','Security','Dynamic','Unified') -What 'Mail-flow settings')) { return }
        $gr = $script:Grp.Raw
        $p = Add-GrpBypass -Parameters @{ Identity = $script:Grp.Smtp; Confirm = $false; ErrorAction = 'Stop' }
        $changed = @()
        if ($chkRequireAuth.Checked -ne [bool]$gr.RequireSenderAuthenticationEnabled) {
            $p['RequireSenderAuthenticationEnabled'] = [bool]$chkRequireAuth.Checked
            $changed += "RequireSenderAuthentication=$($chkRequireAuth.Checked)"
        }
        if ($changed.Count -eq 0) { Set-EditorStatus -Text 'Nothing changed.'; return }

        $extra = ''
        if (-not $chkRequireAuth.Checked -and $gridAllowed.Rows.Count -gt 0) {
            $extra = "`r`n`r`nTURNING AUTHENTICATION OFF DOES NOT CLEAR THE ALLOWED-SENDERS LIST -- it stops the list being enforced. The group becomes open to everyone while still showing $($gridAllowed.Rows.Count) allowed sender(s)."
        } elseif (-not $chkRequireAuth.Checked) {
            $extra = "`r`n`r`nAnyone outside the organisation will be able to send to this group."
        }
        $a = Show-ToolDialog(("On $($script:Grp.Display):" + "`r`n`r`n  " + ($changed -join "`r`n  ") + $extra),
                             'Apply mail-flow settings', 'OKCancel', 'Warning')
        if ($a -ne [System.Windows.Forms.DialogResult]::OK) { return }
        Invoke-GrpCmd -Name (Get-GrpSetCmdlet) -Parameters $p | Out-Null
        Write-EditorAudit -Action 'GroupMailFlow' -Detail ($changed -join '; ')
        $script:Grp = Resolve-GroupTarget -Identity $script:Grp.Smtp -ForceOnPrem:($script:Mode -eq 'OnPrem')
        Update-MailFlowTab
        $script:Loaded['Overview'] = $false
        Set-EditorStatus -Text "Applied: $($changed -join '; ')"
    } 'Apply mail-flow settings'
})

$btnAlAdd.Add_Click({
    if (-not (Test-EditorLoaded)) { return }
    Invoke-EditorAction {
        if (-not (Test-GrpKind -Allow @('Distribution','Security') -What 'Allowed senders')) { return }
        $who = Show-InputListDialog -Title 'Add allowed senders' -Width 620 `
                -Prompt 'Who may send to this group? One per line. A group is allowed. first.last is enough -- the mail domain is added for you.'
        $list = ConvertFrom-DialogList -Text "$who" -CompleteDomain
        if ($list.Count -eq 0) { return }
        $all = @()
        foreach ($row in $gridAllowed.Rows) { if ($row.Tag) { $all += "$(if ($row.Tag.Address) { $row.Tag.Address } else { $row.Tag.Raw })" } }
        foreach ($w in $list) {
            $r = Resolve-GrpRecipient -Entry $w
            if (-not $r.Ok) { Set-EditorStatus -Text "'$w' $($r.Reason). Nothing was changed." -Bad; return }
            if ($all -notcontains $r.Address) { $all += $r.Address }
        }
        $extra = ''
        if (-not [bool]$script:Grp.Raw.RequireSenderAuthenticationEnabled) {
            $extra = "`r`n`r`nNOTE: sender authentication is currently OFF for this group, so this list will be stored and NOT enforced."
        }
        $a = Show-ToolDialog(("Set the allowed senders on $($script:Grp.Display) to:" + "`r`n`r`n  " + ($all -join "`r`n  ") + $extra),
                             'Allowed senders', 'OKCancel', 'Warning')
        if ($a -ne [System.Windows.Forms.DialogResult]::OK) { return }
        Set-GrpAllowedSenders -Senders $all
        Write-EditorAudit -Action 'GroupAllowedSenders' -Detail "AcceptMessagesOnlyFromSendersOrMembers = $($all -join '; ')"
        $script:Grp = Resolve-GroupTarget -Identity $script:Grp.Smtp -ForceOnPrem:($script:Mode -eq 'OnPrem')
        Update-MailFlowTab
        $script:Loaded['Overview'] = $false
        Set-EditorStatus -Text 'Allowed senders applied.'
    } 'Add allowed senders'
})

$btnAlRemove.Add_Click({
    if (-not (Test-EditorLoaded)) { return }
    Invoke-EditorAction {
        if (-not (Test-GrpKind -Allow @('Distribution','Security') -What 'Allowed senders')) { return }
        $picked = Get-GridPicked -Grid $gridAllowed
        if ($picked.Count -eq 0) { Set-EditorStatus -Text 'Tick one or more senders to remove.' -Bad; return }
        $keep = @()
        foreach ($row in $gridAllowed.Rows) {
            if ([bool]$row.Cells['Pick'].Value) { continue }
            if ($row.Tag) { $keep += "$(if ($row.Tag.Address) { $row.Tag.Address } else { $row.Tag.Raw })" }
        }
        $extra = ''
        if ($keep.Count -eq 0) {
            $extra = "`r`n`r`nTHE LIST WILL BE EMPTY. An empty list means anybody may send, subject only to the authentication setting -- it does not mean nobody may send."
        }
        $a = Show-ToolDialog(("Remove $($picked.Count) allowed sender(s) from $($script:Grp.Display)?" + "`r`n`r`n  " +
                              (@($picked | ForEach-Object { $_.Name }) -join "`r`n  ") + $extra),
                             'Remove allowed senders', 'OKCancel', 'Warning')
        if ($a -ne [System.Windows.Forms.DialogResult]::OK) { return }
        Set-GrpAllowedSenders -Senders $keep
        Write-EditorAudit -Action 'GroupAllowedSenders' -Detail "AcceptMessagesOnlyFromSendersOrMembers = $(if ($keep) { $keep -join '; ' } else { '(empty)' })"
        $script:Grp = Resolve-GroupTarget -Identity $script:Grp.Smtp -ForceOnPrem:($script:Mode -eq 'OnPrem')
        Update-MailFlowTab
        $script:Loaded['Overview'] = $false
        Set-EditorStatus -Text "Removed $($picked.Count) allowed sender(s)."
    } 'Remove allowed senders'
})
#endregion

#region Send As tab -------------------------------------------------------------
<#
    WHO MAY SEND AS THIS GROUP -- AND THE TWO SIDES ARE GENUINELY DIFFERENT.

    ON-PREMISES it is an Active Directory permission:
        Add-ADPermission -Identity <the group's DISTINGUISHED NAME>
                         -User <the trustee's sAMAccountName>
                         -ExtendedRights 'Send-As'
      The *-ADPermission cmdlets are AD OBJECT cmdlets. Their -Identity takes
      a name, canonical name, distinguished name or GUID and NOT an SMTP
      address -- given one it fails with "object 'x@y' couldn't be found",
      which reads as a missing group and is nothing of the kind.

    IN THE CLOUD it is a recipient permission:
        Add-RecipientPermission -Identity <smtp> -Trustee <smtp>
                                -AccessRights 'SendAs'

    NOTE THE TWO SPELLINGS. 'Send-As' with a hyphen on-premises, 'SendAs'
    without one in the cloud. They are not interchangeable and neither errors
    usefully when given the other's spelling.

    A DENY IS KEPT AND FLAGGED. A Deny outranks an Allow, so a list that
    quietly dropped them would explain nothing about why somebody still
    cannot send.
#>
$saY = 8
[void](New-TabLabel $tabAccess 'SEND AS' 8 $saY -Bold)
$saY += 22
$saNote = New-TabLabel $tabAccess '' 8 $saY 1040 -Muted
$saNote.Size = New-Object System.Drawing.Size(1040, 32)
$saY += 40
$gridSendAs = New-TabGrid $tabAccess @(@('Name', 360), @('Address', 300), @('Right', 160)) 8 $saY 700 320
Add-GridPickColumn -Grid $gridSendAs
$saBtnY = $saY
$btnSaAdd    = New-TabButton $tabAccess 'Grant Send As...' 720 $saBtnY 170
$saBtnY += 34
$btnSaRemove = New-TabButton $tabAccess 'Revoke ticked'    720 $saBtnY 170
$saBtnY += 34
$btnSaAll    = New-TabButton $tabAccess 'Tick all'         720 $saBtnY 82
$btnSaNone   = New-TabButton $tabAccess 'None'             808 $saBtnY 82
$saY += 332
$saHint = New-TabLabel $tabAccess '' 8 $saY 1040 -Muted
$saHint.Size = New-Object System.Drawing.Size(1040, 46)
$saHint.Text = ('Send As lets somebody send mail that appears to come FROM the group, with no sign of who actually sent it.' + "`r`n" +
                'A row marked DENY overrides any Allow -- if somebody cannot send as the group despite being listed, look for a Deny first.')

function Update-SendAsTab {
    $gridSendAs.Rows.Clear()
    $g = $script:Grp
    # A DYNAMIC GROUP IS NO LONGER REFUSED HERE. Both Get-RecipientPermission
    # and Add-RecipientPermission list 'Dynamic distribution groups' among the
    # recipient types their -Identity accepts, so the old gate was refusing
    # something the service supports.
    #
    # A MICROSOFT 365 GROUP STILL IS, and for the opposite reason: that same
    # documented list names mailboxes, mail users, external contacts,
    # distribution groups and dynamic distribution groups -- and does NOT name
    # Microsoft 365 groups. Unlocking both together, on the strength of having
    # just unlocked M365 groups elsewhere, would have been a guess.
    if ($g.Kind -eq 'Unified') {
        $btnSaAdd.Enabled = $false; $btnSaRemove.Enabled = $false
        $saNote.Text = 'Send As is not edited here for a Microsoft 365 group -- the recipient-permission cmdlets do not list that type among the identities they accept.'
        $saNote.ForeColor = (Get-ToolStatusColour -Kind Warn)
        return
    }
    $btnSaAdd.Enabled = $true; $btnSaRemove.Enabled = $true

    # BOTH SIDES FOR A SYNCED GROUP. Send As is not synchronised, and cloud
    # senders are checked in Exchange Online -- so an on-premises-only read
    # hid every grant that actually works for them. One row per person and
    # right; the Right column says where it exists.
    $rows = @()
    $cloudRead = ''
    try {
        if ($g.OnPrem) {
            # THE DISTINGUISHED NAME, NOT THE ADDRESS.
            foreach ($p in @(Invoke-GrpCmd -Name 'Get-ADPermission' -Parameters @{ Identity = $g.Dn; ErrorAction = 'Stop' })) {
                if ($p.IsInherited) { continue }
                if ("$($p.User)" -match '(?i)NT AUTHORITY\\SELF|\\SELF$|^S-1-5') { continue }
                if (-not (@($p.ExtendedRights) -match 'Send-As')) { continue }
                $rows += [PSCustomObject]@{ Who = "$($p.User)"; Right = $(if ($p.Deny) { 'DENY' } else { 'Allow' }); Side = 'OnPrem' }
            }
        }
    } catch {
        $script:TabReadFailed = $true
        $saNote.Text = "Send As could not be read: $($_.Exception.Message)"
        $saNote.ForeColor = (Get-ToolStatusColour -Kind Bad)
        return
    }
    $exoUp = -not $g.OnPrem
    if ($g.OnPrem) { try { $exoUp = [bool](Test-ExoConnectionState).Connected } catch { } }
    if ($exoUp) {
        try {
            foreach ($p in @(Invoke-EXOCommand -Name 'Get-RecipientPermission' -Parameters @{ Identity = $g.Smtp; ErrorAction = 'Stop' })) {
                if ("$($p.Trustee)" -match '(?i)NT AUTHORITY\\SELF|\\SELF$') { continue }
                if (-not (@($p.AccessRights) -match 'SendAs')) { continue }
                $rows += [PSCustomObject]@{ Who = "$($p.Trustee)"; Right = $(if ("$($p.AccessControlType)" -eq 'Deny') { 'DENY' } else { 'Allow' }); Side = 'Cloud' }
            }
        } catch {
            if (-not $g.OnPrem) {
                $script:TabReadFailed = $true
                $saNote.Text = "Send As could not be read: $($_.Exception.Message)"
                $saNote.ForeColor = (Get-ToolStatusColour -Kind Bad)
                return
            }
            $cloudRead = " The Exchange Online side could not be read: $($_.Exception.Message)"
        }
    } elseif ($g.OnPrem) {
        $cloudRead = ' Exchange Online is not connected, so grants there -- the ones cloud mailboxes actually use -- are not shown.'
    }

    $merged = [ordered]@{}
    foreach ($r in $rows) {
        $res = Resolve-GrpRecipient -Entry $r.Who
        $id  = $(if ("$($res.Address)".Trim()) { "$($res.Address)" } else { "$($r.Who)" })
        $key = ($id.ToLower() + '|' + $r.Right)
        if (-not $merged.Contains($key)) {
            $merged[$key] = [PSCustomObject]@{
                Who = ''; CloudWho = ''; Name = $(if ($res.Ok) { $res.Name } else { $r.Who })
                Address = $res.Address; Sam = $res.Sam; Right = $r.Right; Where = @()
            }
        }
        $m = $merged[$key]
        if ($r.Side -eq 'OnPrem') { $m.Who = $r.Who } else { $m.CloudWho = $r.Who }
        if ($m.Where -notcontains $r.Side) { $m.Where += $r.Side }
        if (-not "$($m.Sam)".Trim() -and "$($res.Sam)".Trim()) { $m.Sam = $res.Sam }
    }
    foreach ($m in $merged.Values) {
        if (-not $m.Who) { $m.Who = $m.CloudWho }
        $label = $m.Right
        if ($g.OnPrem) {
            $side = $(if ($m.Where.Count -gt 1) { 'both' } elseif ($m.Where -contains 'Cloud') { 'cloud' } else { 'on-prem' })
            $label = "$($m.Right) - $side"
        }
        $i = $gridSendAs.Rows.Add($false, $m.Name, $m.Address, $label)
        $gridSendAs.Rows[$i].Tag = $m
        if ($m.Right -eq 'DENY') { $gridSendAs.Rows[$i].DefaultCellStyle.ForeColor = (Get-ToolStatusColour -Kind Bad) }
    }
    $src = $(if ($g.OnPrem) { 'from Active Directory and Exchange Online' } else { 'from Exchange Online' })
    $saNote.Text = "$($gridSendAs.Rows.Count) Send As entry/entries, read $src. Cloud mailboxes use the Exchange Online grant; only mailboxes still on-premises use the AD one. Inherited entries and SELF are not shown.$cloudRead"
    $saNote.ForeColor = $(if ($cloudRead) { (Get-ToolStatusColour -Kind Warn) } else { (Get-ToolStatusColour -Kind Muted) })
}

$btnSaAll.Add_Click({  Set-GridPicked -Grid $gridSendAs -On $true })
$btnSaNone.Add_Click({ Set-GridPicked -Grid $gridSendAs -On $false })

function Test-GrpNeedsOnPremSendAs {
    <#
        Does this person need Send As written in on-premises AD?

        MICROSOFT'S RULE (Permissions in Exchange hybrid deployments; Overview
        of delegation in a Microsoft 365 hybrid environment): Send As is NOT
        synchronised by Entra Connect, and it must exist in the SENDER's
        forest. A person whose mailbox is in Exchange Online is checked by
        Exchange Online -- an AD permission does nothing for them.

        So on an on-premises-mastered group:
          * everyone gets it in Exchange Online (that is where cloud senders
            are checked, and it costs an on-premises sender nothing), and
          * only a sender whose mailbox is still ON-PREMISES also needs it in
            AD. From on-premises, a cloud mailbox reads as Remote*Mailbox.
        Security groups get both, since their members can be on either side.
        An unknown type gets both, rather than guessing.

        This is the fix for 2026-09-25: every Send As on a synced group was
        written ONLY in AD, which was both refused and, for cloud mailboxes,
        the wrong place. The older DL_SendToAs tool that worked for months
        wrote it in Exchange Online.
    #>
    param([string]$Type)
    $ty = "$Type".Trim()
    if (-not $ty) { return $true }
    if ($ty -match '^(User|Shared|Room|Equipment|Linked)Mailbox$') { return $true }
    if ($ty -match '(?i)SecurityGroup') { return $true }
    return $false
}

function Get-GrpSendAsHolders {
    <#
        Who already holds an ALLOW Send As on the loaded group, per side:
        .OnPrem = sAMAccountNames from AD, .Cloud = trustees from Exchange
        Online. A side that was not asked for, or could not be read, is $null
        -- and nobody is skipped on its account. Re-granting is harmless;
        refusing to grant because a read failed is not.
    #>
    param([bool]$Cloud, [bool]$OnPrem)
    $g = $script:Grp
    $res = [PSCustomObject]@{ OnPrem = $null; Cloud = $null }
    if ($OnPrem) {
        try {
            $set = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
            foreach ($p in @(Invoke-GrpCmd -Name 'Get-ADPermission' -Parameters @{ Identity = $g.Dn; ErrorAction = 'Stop' })) {
                if ($p.IsInherited -or $p.Deny) { continue }
                if (-not (@($p.ExtendedRights) -match 'Send-As')) { continue }
                [void]$set.Add((("$($p.User)") -split '\\')[-1])
            }
            $res.OnPrem = $set
        } catch { }
    }
    if ($Cloud) {
        try {
            $set = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
            foreach ($p in @(Invoke-EXOCommand -Name 'Get-RecipientPermission' -Parameters @{ Identity = $g.Smtp; ErrorAction = 'Stop' })) {
                if ("$($p.AccessControlType)" -eq 'Deny') { continue }
                if (-not (@($p.AccessRights) -match 'SendAs')) { continue }
                [void]$set.Add("$($p.Trustee)")
            }
            $res.Cloud = $set
        } catch { }
    }
    return $res
}

function Invoke-GrpSendAsGrantList {
    <#
        Grant Send As on the loaded group to a list of already-resolved people.

        ONE IMPLEMENTATION, TWO DOORS. The Send As tab (typed names) and the
        Members tab (ticked rows) both end here.

        WHERE IT IS WRITTEN. A cloud group: Exchange Online. An on-premises
        (synced) group: Exchange Online for everyone, plus on-premises AD for
        the senders whose mailbox is still on-premises -- see
        Test-GrpNeedsOnPremSendAs for Microsoft's rule and why. If Exchange
        Online is not connected, it falls back to AD only and says so.

        -Skipped carries people the caller could not resolve; they are listed
        in the results rather than silently dropped. Anyone who already has it
        on every side they need is left alone and listed as ALREADY.
    #>
    param([object[]]$Resolved, [string[]]$Skipped = @())
    $g = $script:Grp

    $useCloud = -not $g.OnPrem
    $cloudNote = ''
    if ($g.OnPrem) {
        $exoUp = $false
        try { $exoUp = [bool](Test-ExoConnectionState).Connected } catch { }
        if ($exoUp) {
            # DOES THE GROUP HAVE A CLOUD COPY? An on-premises group reaches
            # Exchange Online only if it is synchronised. Without a copy there
            # is nothing to grant on in the cloud -- and a cloud mailbox then
            # cannot be given Send As on this group from either side. Checked
            # once, so the operator gets one sentence instead of one identical
            # 'couldn't be found' per person.
            $copy = $null
            try { $copy = Invoke-EXOCommand -Name 'Get-Recipient' -Parameters @{ Identity = $g.Smtp; ErrorAction = 'Stop' } } catch { }
            if (@($copy).Count -eq 1) { $useCloud = $true }
            else {
                $cloudNote = "This group has no copy in Exchange Online (it is not synchronised), so Send As was written in on-premises AD only. People whose mailbox is in Exchange Online cannot send as an unsynchronised on-premises group -- it would need to be synchronised, or moved to the cloud."
            }
        } else {
            $cloudNote = 'Exchange Online is not connected, so this was written in on-premises AD only. Anyone whose mailbox is in Exchange Online needs it granted THERE -- connect Exchange Online and grant again.'
        }
    }

    $pre = @()
    foreach ($s in @($Skipped)) { if ("$s".Trim()) { $pre += "SKIPPED $s" } }

    $have = Get-GrpSendAsHolders -Cloud $useCloud -OnPrem ([bool]$g.OnPrem)
    $todo = @()
    foreach ($r in @($Resolved)) {
        $wantCloud  = $useCloud
        $wantOnPrem = [bool]$g.OnPrem -and ((-not $useCloud) -or (Test-GrpNeedsOnPremSendAs -Type "$($r.Type)"))
        if ($wantCloud -and $null -ne $have.Cloud -and "$($r.Address)".Trim() -and $have.Cloud.Contains("$($r.Address)")) { $wantCloud = $false }
        if ($wantOnPrem -and $null -ne $have.OnPrem -and "$($r.Sam)".Trim() -and $have.OnPrem.Contains("$($r.Sam)")) { $wantOnPrem = $false }
        if (-not $wantCloud -and -not $wantOnPrem) { $pre += "ALREADY $($r.Name) -- already has Send As, left alone"; continue }
        $todo += [PSCustomObject]@{ R = $r; Cloud = $wantCloud; OnPrem = $wantOnPrem }
    }
    if ($todo.Count -eq 0) {
        if ($pre.Count) { Show-ResultListDialog -Title 'Grant Send As -- nothing to do' -Lines $pre }
        Set-EditorStatus -Text 'Nothing to grant -- everyone chosen already has Send As, or could not be resolved.' -Warn
        return
    }

    # A long list is cut in the confirmation, never in the results.
    $names = @($todo | ForEach-Object { $_.R.Name })
    $shown = $(if ($names.Count -gt 25) { @($names[0..24]) + "... and $($names.Count - 25) more" } else { $names })
    $nCloud  = @($todo | Where-Object { $_.Cloud }).Count
    $nOnPrem = @($todo | Where-Object { $_.OnPrem }).Count
    $where = @()
    if ($nCloud)  { $where += "Exchange Online for $nCloud" }
    if ($nOnPrem) { $where += "on-premises AD for $nOnPrem (mailbox still on-premises)" }
    $extra = $(if ($pre.Count) { "`r`n`r`n$($pre.Count) other(s) left out -- already have it, or could not be resolved. They are listed in the results." } else { '' })
    $a = Show-ToolDialog(
        ("Let these $($todo.Count) people send AS $($g.Display)?" + "`r`n`r`n  " +
         ($shown -join "`r`n  ") + $extra + "`r`n`r`n" +
         "Written in: $($where -join '; ')." + "`r`n`r`n" +
         'Mail they send will appear to come from the group, with no sign of who actually sent it.'),
        'Grant Send As', 'OKCancel', 'Warning')
    if ($a -ne [System.Windows.Forms.DialogResult]::OK) { return }

    $lines = @($pre); $ok = 0; $bad = 0
    # ONE AD REFUSAL MEANS ALL AD WRITES. The ACL is on the group, so after
    # the first refusal the other AD writes are not attempted. Exchange Online
    # writes carry on -- they are a different directory and a different check.
    $denied = $false
    foreach ($it in $todo) {
        $r = $it.R
        $done = @(); $err = @()
        if ($it.Cloud) {
            try {
                Invoke-EXOCommand -Name 'Add-RecipientPermission' -Parameters @{
                    Identity = $g.Smtp; Trustee = $r.Address; AccessRights = 'SendAs'
                    Confirm = $false; ErrorAction = 'Stop' } | Out-Null
                $done += 'Exchange Online'
            } catch {
                if ("$($_.Exception.Message)" -match '(?i)already') { $done += 'Exchange Online (was already there)' }
                else { $err += "Exchange Online: $($_.Exception.Message)" }
            }
        }
        if ($it.OnPrem) {
            if ($denied) { $err += 'on-premises AD: not attempted -- same group, same refusal' }
            else {
                try {
                    [void](Invoke-GrpSendAsWrite -Name 'Add-ADPermission' -Parameters @{
                        Identity = $g.Dn; User = $r.Sam; ExtendedRights = 'Send-As'
                        Confirm = $false; ErrorAction = 'Stop' })
                    $done += 'on-premises AD'
                } catch {
                    $err += "on-premises AD: $($_.Exception.Message)"
                    if (Test-AdAccessDenied -ErrorRecord $_) { $denied = $true }
                }
            }
        }
        if ($err.Count -eq 0)   { $lines += "OK      $($r.Name) -- $($done -join ' + ')"; $ok++ }
        elseif ($done.Count)    { $lines += "PARTIAL $($r.Name) -- done: $($done -join ' + ') | failed: $($err -join ' | ')"; $bad++ }
        else                    { $lines += "FAILED  $($r.Name): $($err -join ' | ')"; $bad++ }
    }
    if ($cloudNote) { $lines += ''; $lines += $cloudNote }
    if ($denied) {
        $lines += ''
        $lines += 'The AD refusal below only matters for senders whose mailbox is still on-premises.'
        $lines += @(Get-AdWriteDenialReport -Dn $g.Dn -Server "$($script:DCParam['DomainController'])")
    }
    Write-EditorAudit -Action 'GroupSendAsGrant' -Result $(if ($bad -and $ok) { 'Partial' } elseif ($bad) { 'Failed' } else { 'Success' }) `
        -Detail "Send As granted to $(($todo | ForEach-Object { $_.R.Address }) -join '; ')"
    Show-ResultListDialog -Title "Grant Send As -- $ok done, $bad not fully done" -Lines $lines
    Update-SendAsTab
    $lag = $(if ($g.OnPrem -and $ok) { ' If a new entry is not listed yet, Refresh in a minute -- replication can trail the list.' } else { '' })
    Set-EditorStatus -Text "Granted $ok, not fully done $bad.$lag" -Bad:($bad -gt 0)
}

$btnSaAdd.Add_Click({
    if (-not (Test-EditorLoaded)) { return }
    Invoke-EditorAction {
        if (-not (Test-GrpKind -Allow @('Distribution','Security') -What 'Send As')) { return }
        $who = Show-InputListDialog -Title 'Grant Send As' -Width 620 `
                -Prompt 'Who should be able to send as this group? One per line. first.last is enough -- the mail domain is added for you.'
        $list = ConvertFrom-DialogList -Text "$who" -CompleteDomain
        if ($list.Count -eq 0) { return }
        $resolved = @()
        foreach ($w in $list) {
            $r = Resolve-GrpRecipient -Entry $w
            if (-not $r.Ok) { Set-EditorStatus -Text "'$w' $($r.Reason). Nothing was changed." -Bad; return }
            if ($script:Grp.OnPrem -and -not "$($r.Sam)".Trim()) {
                Set-EditorStatus -Text "'$w' has no sAMAccountName, and the on-premises Send As permission needs one." -Bad; return
            }
            $resolved += $r
        }
        Invoke-GrpSendAsGrantList -Resolved $resolved
    } 'Grant Send As'
})

$btnSaRemove.Add_Click({
    if (-not (Test-EditorLoaded)) { return }
    Invoke-EditorAction {
        if (-not (Test-GrpKind -Allow @('Distribution','Security') -What 'Send As')) { return }
        $picked = Get-GridPicked -Grid $gridSendAs
        if ($picked.Count -eq 0) { Set-EditorStatus -Text 'Tick one or more entries to revoke.' -Bad; return }
        $deny = @($picked | Where-Object { $_.Right -eq 'DENY' })
        $extra = $(if ($deny.Count) { "`r`n`r`n$($deny.Count) of these are DENY entries. Removing a Deny GRANTS access to whatever Allow was underneath it." } else { '' })
        $a = Show-ToolDialog(("Revoke Send As for $($picked.Count) entry/entries on $($script:Grp.Display)?" + "`r`n`r`n  " +
                              (@($picked | ForEach-Object { "$($_.Name)  ($($_.Right))" }) -join "`r`n  ") + $extra),
                             'Revoke Send As', 'OKCancel', 'Warning')
        if ($a -ne [System.Windows.Forms.DialogResult]::OK) { return }
        $lines = @(); $ok = 0; $bad = 0
        $denied = $false
        foreach ($e in $picked) {
            # EVERY SIDE THE ROW EXISTS ON. A synced group can hold the grant
            # in AD, in Exchange Online, or both; revoking one side only would
            # leave the person able to send.
            $sides = @($e.Where)
            if ($sides.Count -eq 0) { $sides = @($(if ($script:Grp.OnPrem) { 'OnPrem' } else { 'Cloud' })) }
            $done = @(); $err = @()
            if ($sides -contains 'OnPrem') {
                try {
                    # -Deny IS NOT OPTIONAL FOR A DENY ROW. Without it the
                    # cmdlet targets the ALLOW entry, reports success, and
                    # leaves the Deny in place -- so the person still cannot
                    # send and the window says it fixed it.
                    $rp = @{
                        Identity = $script:Grp.Dn; User = $(if ($e.Sam) { $e.Sam } else { $e.Who })
                        ExtendedRights = 'Send-As'; Confirm = $false; ErrorAction = 'Stop'
                    }
                    if ($e.Right -eq 'DENY') { $rp['Deny'] = $true }
                    [void](Invoke-GrpSendAsWrite -Name 'Remove-ADPermission' -Parameters $rp)
                    $done += 'on-premises AD'
                } catch {
                    $err += "on-premises AD: $($_.Exception.Message)"
                    if (Test-AdAccessDenied -ErrorRecord $_) { $denied = $true }
                }
            }
            if ($sides -contains 'Cloud') {
                try {
                    Invoke-EXOCommand -Name 'Remove-RecipientPermission' -Parameters @{
                        Identity = $script:Grp.Smtp; Trustee = $(if ($e.CloudWho) { $e.CloudWho } elseif ($e.Address) { $e.Address } else { $e.Who }); AccessRights = 'SendAs'
                        Confirm = $false; ErrorAction = 'Stop' } | Out-Null
                    $done += 'Exchange Online'
                } catch { $err += "Exchange Online: $($_.Exception.Message)" }
            }
            if ($err.Count -eq 0) { $lines += "OK      $($e.Name) -- $($done -join ' + ')"; $ok++ }
            elseif ($done.Count)  { $lines += "PARTIAL $($e.Name) -- done: $($done -join ' + ') | failed: $($err -join ' | ')"; $bad++ }
            else                  { $lines += "FAILED  $($e.Name): $($err -join ' | ')"; $bad++ }
        }
        if ($denied) {
            $lines += ''
            $lines += @(Get-AdWriteDenialReport -Dn $script:Grp.Dn -Server "$($script:DCParam['DomainController'])")
        }
        Write-EditorAudit -Action 'GroupSendAsRevoke' -Result $(if ($bad -and $ok) { 'Partial' } elseif ($bad) { 'Failed' } else { 'Success' }) `
            -Detail "Send As revoked for $(($picked | ForEach-Object { $_.Who }) -join '; ')"
        Show-ResultListDialog -Title "Revoke Send As -- $ok done, $bad failed" -Lines $lines
        Update-SendAsTab
        $lag = $(if ($script:Grp.OnPrem -and $ok) { ' If a removed entry still shows, Refresh in a minute -- Exchange chose the controller, and replication can trail the list.' } else { '' })
        Set-EditorStatus -Text "Revoked $ok, failed $bad.$lag" -Bad:($bad -gt 0)
    } 'Revoke Send As'
})
#endregion

#region Addresses tab -----------------------------------------------------------
<#
    THE SAME TAB THE MAILBOX EDITOR HAS, for a group.

    This used to be a read-only grid on Overview with a note saying a rename
    belongs in a tool that does the whole job. That was true of a RENAME. It
    was never true of adding an alias, removing one, or making an existing
    alias the primary -- all three keep the X500 and the LegacyExchangeDN
    exactly where they are, because none of them rebuilds the collection.

    WRITES GO WHERE THE GROUP IS MASTERED. Invoke-GrpCmd is the one place that
    knows, so this tab does not: it names the cmdlet for the group's kind and
    hands the parameters over.

    E-MAIL ADDRESS POLICY. An on-premises group with EmailAddressPolicyEnabled
    set has its addresses rebuilt from the policy, so an edit here is rejected
    or reverted. The tab says so and greys the buttons rather than letting an
    Apply fail with a message about syntax.
#>
$adY = 8
[void](New-TabLabel $tabAddresses 'EMAIL ADDRESSES' 8 $adY -Bold)
$adY += 22
$adNote = New-TabLabel $tabAddresses '' 8 $adY 1050 -Muted
$adY += 22
$gridAddr = New-TabGrid $tabAddresses @(@('Address', 460), @('Type', 90), @('Primary', 80)) 8 $adY 700 320
$adBtnY = $adY
$btnAddrPrimary = New-TabButton $tabAddresses 'Make primary...' 720 $adBtnY 160
$adBtnY += 34
$btnAddrAdd     = New-TabButton $tabAddresses 'Add alias...' 720 $adBtnY 160
$adBtnY += 34
$btnAddrRemove  = New-TabButton $tabAddresses 'Remove selected' 720 $adBtnY 160
$adBtnY += 44
$adWarn = New-TabLabel $tabAddresses '' 720 $adBtnY 340 -Muted
$adWarn.Size = New-Object System.Drawing.Size(340, 120)
$adY += 332

# ---- the e-mail address policy, directly below the list --------------------
# THE SAME ROW THE MAILBOX EDITOR HAS, for the same reason: while the flag is
# set, Exchange rebuilds the list above from the policy, and the buttons above
# are greyed. This is where it gets cleared, on the tab where it bites.
# Set-DistributionGroup -EmailAddressPolicyEnabled is documented on-premises
# only, so the row is live for a group mastered in Active Directory and greyed
# with the reason for a cloud one.
[void](New-TabLabel $tabAddresses 'E-MAIL ADDRESS POLICY' 8 $adY -Bold)
$adY += 22
$chkAddrPolicy = New-Object System.Windows.Forms.CheckBox
$chkAddrPolicy.Location = New-Object System.Drawing.Point(8, $adY)
$chkAddrPolicy.Size     = New-Object System.Drawing.Size(660, 20)
$chkAddrPolicy.Text     = 'Automatically update e-mail addresses based on the e-mail address policy'
$tabAddresses.Controls.Add($chkAddrPolicy)
$btnAddrPolicy = New-TabButton $tabAddresses 'Apply' 680 ($adY - 3) 100
$adY += 26
$adPolNote = New-TabLabel $tabAddresses '' 8 $adY 1040 -Muted
$adPolNote.Size = New-Object System.Drawing.Size(1040, 32)
$adY += 36

function Update-GrpAddressPolicyRow {
    $gr = $script:Grp.Raw
    $known = ($gr -and $gr.PSObject.Properties['EmailAddressPolicyEnabled'])
    $chkAddrPolicy.Checked = [bool]($known -and $gr.EmailAddressPolicyEnabled)
    if (-not $script:Grp.OnPrem) {
        $chkAddrPolicy.Enabled = $false; $btnAddrPolicy.Enabled = $false
        $adPolNote.Text = $(if ($script:Grp.Kind -eq 'Unified') { 'Not applicable to a Microsoft 365 group.' }
                            else { 'This is an on-premises attribute. It applies to a group mastered in Active Directory; this one is being edited in Exchange Online.' })
        $adPolNote.ForeColor = (Get-ToolStatusColour -Kind Muted)
        return
    }
    if (-not $known) {
        $chkAddrPolicy.Enabled = $false; $btnAddrPolicy.Enabled = $false
        $adPolNote.Text = 'The on-premises object does not report this attribute.'
        $adPolNote.ForeColor = (Get-ToolStatusColour -Kind Warn)
        return
    }
    $chkAddrPolicy.Enabled = $true; $btnAddrPolicy.Enabled = $true
    $adPolNote.Text = $(if ($gr.EmailAddressPolicyEnabled) {
            'ON: Exchange builds this group''s addresses from the policy and will revert or reject anything set in the list above. Untick and Apply to take manual control.'
        } else {
            'Off: the addresses above are maintained by hand. Ticking this hands them back to the policy, which may REPLACE them.'
        })
    $adPolNote.ForeColor = (Get-ToolStatusColour -Kind Muted)
}

$btnAddrPolicy.Add_Click({
    if (-not (Test-EditorLoaded)) { return }
    Invoke-EditorAction {
        if (-not $script:Grp.OnPrem) { Set-EditorStatus -Text 'The address policy applies to a group mastered in Active Directory.' -Bad; return }
        if ($script:Grp.Kind -eq 'Dynamic' -or $script:Grp.Kind -eq 'Unified') { Set-EditorStatus -Text 'Not applicable to this kind of group.' -Bad; return }
        $now  = [bool]$script:Grp.Raw.EmailAddressPolicyEnabled
        $want = [bool]$chkAddrPolicy.Checked
        if ($now -eq $want) { Set-EditorStatus -Text 'Already set that way.'; return }
        $msg = $(if ($want) {
                ("Hand $($script:Grp.Display)'s addresses back to the e-mail address policy?" + "`r`n`r`n" +
                 "Exchange will REBUILD the address list from the policy at the next stamp. Addresses the policy does not produce can be removed, and the PRIMARY address can change -- which changes what mail to this group is addressed to." + "`r`n`r`n" +
                 "X500 entries are normally preserved, but check the list afterwards.")
            } else {
                ("Take manual control of $($script:Grp.Display)'s addresses?" + "`r`n`r`n" +
                 "The current addresses stay exactly as they are and the policy stops maintaining them. Future policy changes will NOT reach this group -- it is maintained by hand from now on." + "`r`n`r`n" +
                 "This is what has to be off before an address on this tab can be edited.")
            })
        $a = Show-ToolDialog($msg, 'E-mail address policy', 'OKCancel', 'Warning')
        if ($a -ne [System.Windows.Forms.DialogResult]::OK) { return }
        Invoke-GrpCmd -Name 'Set-DistributionGroup' -Parameters @{
            Identity = $script:Grp.Smtp; EmailAddressPolicyEnabled = $want; BypassSecurityGroupManagerCheck = $true; ErrorAction = 'Stop' } | Out-Null
        Write-EditorAudit -Action 'GroupAddressPolicy' -Environment 'OnPrem' -Detail "EmailAddressPolicyEnabled $now -> $want."
        Invoke-GrpAddressReload
        Set-EditorStatus -Text "E-mail address policy $(if ($want) { 'enabled' } else { 'disabled' }). $($script:OnPremSyncNotice)"
    } 'Change the e-mail address policy setting'
})

function Get-GrpAddressCmdlet {
    # KEPT AS A NAME, NOT A SECOND COPY. It was identical to Get-GrpSetCmdlet
    # and two copies of the same switch is how one of them comes to know about
    # a group kind the other does not -- which is the bug this batch fixed.
    return (Get-GrpSetCmdlet)
}

function Test-GrpAddressesWritable {
    # Returns $true, or sets the warning and returns $false.
    $gr = $script:Grp.Raw
    if ($script:Grp.OnPrem -and $gr.PSObject.Properties['EmailAddressPolicyEnabled'] -and $gr.EmailAddressPolicyEnabled) {
        $adWarn.Text = 'The e-mail address POLICY is enabled on this group on-premises, so Exchange rebuilds its addresses from the policy and will reject or revert anything set here. Untick the policy row below and Apply, or change the policy.'
        $adWarn.ForeColor = (Get-ToolStatusColour -Kind Warn)
        return $false
    }
    if ($script:Grp.IsSynced -and -not $script:Grp.OnPrem) {
        $adWarn.Text = 'This group is synced from Active Directory and this window is in cloud mode. A cloud write is accepted and undone by the next directory sync -- set Editing to On-premises.'
        $adWarn.ForeColor = (Get-ToolStatusColour -Kind Warn)
        return $false
    }
    return $true
}

function Update-AddressesTab {
    $gridAddr.Rows.Clear()
    $gr = $script:Grp.Raw
    foreach ($a in @($gr.EmailAddresses)) {
        $str = "$a"
        if (-not $str) { continue }
        $prefix = ''; $addr = $str
        if ($str -match '^([A-Za-z0-9]+):(.*)$') { $prefix = $Matches[1]; $addr = $Matches[2] }
        $isPrimary = ($prefix -ceq 'SMTP')
        $i = $gridAddr.Rows.Add($addr, $(if ($prefix -match '(?i)^smtp$') { 'SMTP' } else { $prefix }), $(if ($isPrimary) { 'PRIMARY' } else { '' }))
        $gridAddr.Rows[$i].Tag = $str
        if ($isPrimary) {
            $gridAddr.Rows[$i].DefaultCellStyle.Font = New-Object System.Drawing.Font('Consolas', 9, [System.Drawing.FontStyle]::Bold)
        } elseif ($prefix -notmatch '(?i)^smtp$') {
            $gridAddr.Rows[$i].DefaultCellStyle.ForeColor = (Get-ToolStatusColour -Kind Muted)
        }
    }
    $adNote.Text = "$($gridAddr.Rows.Count) address(es). The primary is in bold; X500 entries are what let replies to old mail resolve and are never removed automatically."
    $can = Test-GrpAddressesWritable
    if ($can) {
        $adWarn.Text = "Written with $(Get-GrpAddressCmdlet)$(if ($script:Grp.OnPrem) { ' on-premises. ' + $script:OnPremSyncNotice } else { ' in Exchange Online.' })"
        $adWarn.ForeColor = (Get-ToolStatusColour -Kind Muted)
    }
    $btnAddrPrimary.Enabled = $can; $btnAddrAdd.Enabled = $can; $btnAddrRemove.Enabled = $can
    Update-GrpAddressPolicyRow
}

function Invoke-GrpAddressReload {
    $script:Grp = Resolve-GroupTarget -Identity $script:Grp.Smtp -ForceOnPrem:($script:Mode -eq 'OnPrem')
    Update-EditorIdentity
    Update-AddressesTab
    $script:Loaded['Overview'] = $false
}

$btnAddrPrimary.Add_Click({
    if (-not (Test-EditorLoaded)) { return }
    Invoke-EditorAction {
        if (-not (Test-GrpAddressesWritable)) { return }
        if ($gridAddr.SelectedRows.Count -eq 0) { Set-EditorStatus -Text 'Select the address to make primary.' -Bad; return }
        $row  = $gridAddr.SelectedRows[0]
        $addr = "$($row.Cells['Address'].Value)"
        if ("$($row.Cells['Type'].Value)" -notmatch '(?i)^smtp$') { Set-EditorStatus -Text 'Only an SMTP address can be the primary.' -Bad; return }
        if ("$($row.Cells['Primary'].Value)") { Set-EditorStatus -Text "$addr is already the primary."; return }
        $a = Show-ToolDialog(
            ("Make $addr the primary address for $($script:Grp.Display)?" + "`r`n`r`n" +
             "The current primary is kept as an alias, so mail to it still delivers. Every other entry, including X500, is untouched." + "`r`n`r`n" +
             "Address books and cached Outlook entries can take a while to catch up."),
            'Change primary address', 'OKCancel', 'Warning')
        if ($a -ne [System.Windows.Forms.DialogResult]::OK) { return }
        # -PrimarySmtpAddress IS A REAL PARAMETER on every group cmdlet, and it
        # demotes the old primary to an alias itself. No rebuild, no X500 risk.
        $p = @{ Identity = $script:Grp.Smtp; PrimarySmtpAddress = $addr; ErrorAction = 'Stop' }
        if ($script:Grp.Kind -ne 'Dynamic' -and $script:Grp.Kind -ne 'Unified') { $p['BypassSecurityGroupManagerCheck'] = $true }
        Invoke-GrpCmd -Name (Get-GrpAddressCmdlet) -Parameters $p | Out-Null
        Write-EditorAudit -Action 'GroupPrimaryAddress' -Detail "Primary set to $addr."
        Invoke-GrpAddressReload
        Set-EditorStatus -Text "Primary address is now $addr."
    } 'Change primary address'
})

$btnAddrAdd.Add_Click({
    if (-not (Test-EditorLoaded)) { return }
    Invoke-EditorAction {
        if (-not (Test-GrpAddressesWritable)) { return }
        $new = Show-InputDialog -Title 'Add alias' -Width 520 `
                -Prompt "New SMTP alias for $($script:Grp.Display). It becomes an alias, not the primary:"
        $new = "$new".Trim()
        if (-not $new) { return }
        if ($new -notmatch '^[^@\s]+@[^@\s]+\.[^@\s]+$') { Set-EditorStatus -Text 'That does not look like an email address.' -Bad; return }
        $p = @{ Identity = $script:Grp.Smtp; EmailAddresses = @{ Add = "smtp:$new" }; ErrorAction = 'Stop' }
        if ($script:Grp.Kind -ne 'Dynamic' -and $script:Grp.Kind -ne 'Unified') { $p['BypassSecurityGroupManagerCheck'] = $true }
        Invoke-GrpCmd -Name (Get-GrpAddressCmdlet) -Parameters $p | Out-Null
        Write-EditorAudit -Action 'GroupAddressAdd' -Detail "Alias $new added."
        Invoke-GrpAddressReload
        Set-EditorStatus -Text "Added alias $new."
    } 'Add alias'
})

$btnAddrRemove.Add_Click({
    if (-not (Test-EditorLoaded)) { return }
    Invoke-EditorAction {
        if (-not (Test-GrpAddressesWritable)) { return }
        if ($gridAddr.SelectedRows.Count -eq 0) { Set-EditorStatus -Text 'Select the address to remove.' -Bad; return }
        $row  = $gridAddr.SelectedRows[0]
        $full = "$($row.Tag)"
        $addr = "$($row.Cells['Address'].Value)"
        if ("$($row.Cells['Primary'].Value)") {
            $null = Show-ToolDialog('The primary address cannot be removed. Make another address primary first -- the old one is kept as an alias.',
                                    'Primary address', 'OK', 'Information')
            return
        }
        $extra = ''
        if ("$($row.Cells['Type'].Value)" -match '(?i)^x500$') {
            $extra = "`r`n`r`nTHIS IS AN X500 ADDRESS. It is what lets replies to older mail find this group. Removing it makes those replies bounce, and the failure appears weeks later."
        }
        $a = Show-ToolDialog(("Remove $addr from $($script:Grp.Display)?" + "`r`n`r`nMail sent to it will stop delivering." + $extra),
                             'Remove address', 'OKCancel', 'Warning')
        if ($a -ne [System.Windows.Forms.DialogResult]::OK) { return }
        $p = @{ Identity = $script:Grp.Smtp; EmailAddresses = @{ Remove = $full }; ErrorAction = 'Stop' }
        if ($script:Grp.Kind -ne 'Dynamic' -and $script:Grp.Kind -ne 'Unified') { $p['BypassSecurityGroupManagerCheck'] = $true }
        Invoke-GrpCmd -Name (Get-GrpAddressCmdlet) -Parameters $p | Out-Null
        Write-EditorAudit -Action 'GroupAddressRemove' -Detail "Address $full removed."
        Invoke-GrpAddressReload
        Set-EditorStatus -Text "Removed $addr."
    } 'Remove address'
})
#endregion

#region Load and tab switching --------------------------------------------------
function Invoke-GrpLoad {
    $t = "$($txtGrp.Text)".Trim()
    if (-not $t) { Set-EditorStatus -Text 'Enter a group address.' -Bad; return }
    Set-EditorStatus -Text "Resolving $t..."
    $g = Resolve-GroupTarget -Identity $t -ForceOnPrem:($OnPrem -or $script:Mode -eq 'OnPrem')
    if (-not $g.Ok) {
        $script:Grp = $null
        $lblIdent.Text = ''; $lblSync.Text = ''
        Set-EditorStatus -Text "'$t' $($g.Reason)" -Bad
        return
    }
    $script:Grp    = $g
    $script:Loaded = @{}
    # THE CONTROLLER IS PINNED ONCE PER LOAD, and only when this group is
    # going to be written on-premises.
    if ($g.OnPrem) { Set-GrpDomainController } else { $script:DCParam = @{} }

    # THE SWITCH FOLLOWS THE OBJECT. A synced group loads in on-premises mode
    # because that is where its writes have to go; the operator can still
    # override it, which is the whole reason the switch exists.
    $script:Mode = $(if ($g.OnPrem) { 'OnPrem' } else { 'Cloud' })
    Sync-EditorModeCombo -Combo $cmbMode -Mode $script:Mode

    Update-EditorIdentity
    $script:TabReadFailed = $false
    Update-OverviewTab
    if (-not $script:TabReadFailed) { $script:Loaded['Overview'] = $true }
    Invoke-EditorTabLoad -Key "$($tabs.SelectedTab.Name)"
    Set-EditorStatus -Text "Loaded $($g.Smtp) $(if ($g.FoundIn -eq 'OnPrem') { 'from Active Directory' } else { 'from Exchange Online' })."

}



$cmbMode.Add_SelectedIndexChanged({
    $want = $(if ($cmbMode.SelectedIndex -eq 1) { 'OnPrem' } else { 'Cloud' })
    if ($script:Busy) { Sync-EditorModeCombo -Combo $cmbMode -Mode $script:Mode; return }
    if ($want -eq $script:Mode) { return }
    Invoke-EditorAction { Set-EditorMode -Mode $want } 'Switch editing mode'
})

$btnLoad.Add_Click({ Invoke-EditorAction { Invoke-GrpLoad } 'Load group' })
$txtGrp.Add_KeyDown({ if ($_.KeyCode -eq 'Return') { $btnLoad.PerformClick(); $_.SuppressKeyPress = $true } })

# TAB CHANGE AND WINDOW CLOSE ARE WIRED BY THE SHARED RUNTIME, guards included.
Register-EditorTabHandler
#endregion

Set-ConsoleTheme -Form $form
Set-FormScreenCorner -Form $form -Corner 'BottomLeft'
Add-ToolHelpButton -Form $form -ScriptPath $PSCommandPath -Title 'Group Editor' | Out-Null

$form.Add_Shown({
    # THE REASON GOES ON THE SIDE BANNER, not the status line -- the load on
    # the next line overwrites the status line before anyone can read it.
    $script:OnPremWhy = Set-EditorModeAvailability -Combo $cmbMode
    if ($script:OnPremWhy) {
        $lblSync.Text = "On-premises editing is unavailable: $($script:OnPremWhy)"
        $lblSync.ForeColor = (Get-ToolStatusColour -Kind Muted)
    }
    # -OnPrem IS A REQUEST, NOT A GUARANTEE. Honouring it when the probe has
    # just said there is no on-premises session sends every read to a module
    # that is not loaded.
    if ($OnPrem -and $cmbMode.Enabled) { $script:Mode = 'OnPrem'; Sync-EditorModeCombo -Combo $cmbMode -Mode 'OnPrem' }
    if ("$($txtGrp.Text)".Trim()) { $btnLoad.PerformClick() }
})


[void]$form.ShowDialog()

# DISPOSE IS WRAPPED, AND THAT IS NOT LAZINESS.
#
# ShowDialog has already returned, so the window is shut and every write this
# tool was going to make is made. Dispose here is returning handles to the OS.
# If .NET's own TabControl teardown indexes past the end of its page
# collection -- which it does, and which the guards above make far less likely
# but cannot make impossible -- the operator should not be shown a stack trace
# for a window they already closed. The process is ending; the handles go back
# either way.
try { $form.Dispose() } catch { }
